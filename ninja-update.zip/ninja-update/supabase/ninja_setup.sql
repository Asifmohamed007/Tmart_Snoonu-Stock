-- =====================================================================
-- FreshQA Stock - add Ninja (keeps Snoonu, Talabat, Fruity Friends)
-- Supabase -> SQL Editor -> New query -> paste ALL of this -> Run.
-- Safe to run again.
-- =====================================================================

-- 1. Allow the new source
alter table public.jobs drop constraint if exists jobs_source_check;
alter table public.jobs add constraint jobs_source_check
  check (source in ('snoonu', 'talabat', 'fruity', 'ninja'));

-- 2. Refreshes can carry options (Fruity Friends: Morning or Evening)
alter table public.jobs add column if not exists options jsonb not null default '{}'::jsonb;

-- 3. Replace the refresh function (same name, now with options)
drop function if exists public.request_refresh(text);
drop function if exists public.request_refresh(text, jsonb);

create function public.request_refresh(p_source text, p_options jsonb default '{}'::jsonb)
returns public.jobs
language plpgsql
security definer
set search_path = public
as $$
declare
  j public.jobs;
  opts jsonb := coalesce(p_options, '{}'::jsonb);
begin
  if p_source not in ('snoonu', 'talabat', 'fruity', 'ninja') then
    raise exception 'Unknown source %', p_source;
  end if;
  if p_source = 'fruity' then
    if coalesce(opts->>'session', '') not in ('morning', 'evening') then
      raise exception 'Pick Morning or Evening';
    end if;
    opts := jsonb_build_object('session', opts->>'session');
  else
    opts := '{}'::jsonb;
  end if;

  select * into j
  from public.jobs
  where source = p_source
    and (status = 'pending'
         or (status = 'running' and started_at > now() - interval '90 minutes'))
  order by requested_at desc
  limit 1;

  if found then
    return j;
  end if;

  insert into public.jobs (source, options) values (p_source, opts) returning * into j;
  return j;
end;
$$;

revoke all on function public.request_refresh(text, jsonb) from public;
grant execute on function public.request_refresh(text, jsonb) to anon, authenticated;

-- 4. Make the website see the new function straight away
notify pgrst, 'reload schema';
