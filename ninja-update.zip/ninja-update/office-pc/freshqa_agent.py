"""
FreshQA Stock Agent  (runs quietly on the office PC)
-----------------------------------------------------
The website (Netlify) only shows the screens. This program does the real work:

  1. Every few seconds it asks Supabase: "has anyone tapped Refresh now?"
  2. If yes, it reads Snoonu or Talabat (your PC can - their sites block
     cloud servers), and sends live progress so the website can animate it.
  3. It fills your Excel template exactly like your Python scripts do,
     uploads the file to Supabase, and sends the stock table to the website.

Snoonu and Talabat can run at the same time (one worker each).
snoonu.py and talabat.py are re-loaded on every refresh, so edits to them
apply on the next tap of Refresh now - no restart needed.
Everything here - code, templates, keys - stays on this PC only.

FOLDER (put this file in the same folder as these):
    snoonu.py             Snoonu branches + logic (edit freely)
    talabat.py            Talabat branches + logic (edit freely)
    fruity_friends_master.py  Fruity Friends (Talabat + Snoonu) - edit freely
    All_Stock_Temp.xlsx   the Fruity Friends workbook (or set WORKBOOK_PATH in that file)
    ninja_stock.py        Ninja (Al Nasr + Al Gharafa) - edit freely
    Ninja_Stock.xlsx      the Ninja workbook (or set WORKBOOK_PATH in that file)
    Talabat_Temp.xlsx     Talabat template
    Snoonu_Stock.xlsx     Snoonu template
    .talabat_*.json       Talabat's learned speed/categories (if you have them)

Requirements (install once):
    pip install requests openpyxl
"""

import os
import re
import sys
import json
import time
import importlib
import shutil
import importlib.util
import socket
import logging
import datetime
import threading
import traceback

import requests
from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)                 # talabat.py uses relative paths for its files
sys.path.insert(0, HERE)

# ---------------------------------------------------------------------------
# CONFIGURE THESE TWO  (Supabase -> Project Settings -> API Keys)
# ---------------------------------------------------------------------------

SUPABASE_URL = "https://zraicjnfeycewtgufamd.supabase.co/rest/v1/"          # https://xxxx.supabase.co
SUPABASE_SERVICE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpyYWljam5mZXljZXd0Z3VmYW1kIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc5MTgwNTM5MiwiZXhwIjoyMTA3MzgxMzkyfQ.yG0ZX_Ly_P7LKql_XuokjAN9YCmgyEfpgeiT4HdTzx0"  # keep secret - PC only

# ---------------------------------------------------------------------------

AGENT_VERSION = "1.5"
POLL_SECONDS = 4
HEARTBEAT_SECONDS = 15
KEEP_DAYS = 60                 # older refreshes (and their files) are removed
OUT_DIR = os.path.join(HERE, "reports")

# Notifications ("Talabat is ready") - created by make_push_keys.py
VAPID_PRIVATE_KEY_FILE = os.path.join(HERE, "vapid_private.pem")
VAPID_CONTACT = "mailto:stock@freshqa.qa"   # any contact address, required by the push services
NOTIFY_SOURCES = {"talabat", "snoonu", "fruity", "ninja"}   # remove one to stop its notifications
SOURCE_NAMES = {"snoonu": "Snoonu", "talabat": "Talabat", "fruity": "Fruity Friends", "ninja": "Ninja"}
FRUITY_MODULE = "fruity_friends_master"     # your Fruity Friends script, without ".py"
NINJA_MODULE = "ninja_stock"                # your Ninja script, without ".py"

# Talabat and Fruity Friends both read talabat.com - running them at the same
# time would make Talabat slow both down, so they take turns.
_TALABAT_SITE = threading.Lock()
SITE_LOCKS = {"talabat": _TALABAT_SITE, "fruity": _TALABAT_SITE}
BUCKET = "reports"

# ---------------------------------------------------------------------------
# Logging (pythonw has no window, so everything goes to freshqa_agent.log)
# ---------------------------------------------------------------------------

logging.basicConfig(filename=os.path.join(HERE, "freshqa_agent.log"), level=logging.INFO,
                    format="%(asctime)s  %(threadName)-8s %(message)s")
log = logging.getLogger("agent")
if sys.stdout and hasattr(sys.stdout, "isatty") and sys.stdout.isatty():
    log.addHandler(logging.StreamHandler(sys.stdout))


def utcnow():
    return datetime.datetime.now(datetime.timezone.utc)


def iso(dt=None):
    return (dt or utcnow()).isoformat()


def local_stamp():
    return datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")


# ===========================================================================
# Supabase (plain REST, no extra libraries)
# ===========================================================================

class Supabase:
    def __init__(self, url, key):
        from urllib.parse import urlsplit
        parts = urlsplit(url.strip())
        # accept "https://x.supabase.co", ".../", ".../rest/v1/" etc.
        self.url = f"{parts.scheme}://{parts.netloc}" if parts.netloc else url.strip().rstrip("/")
        key = key.strip()
        self.key = key
        self.s = requests.Session()
        self.s.headers["apikey"] = key
        if not key.startswith("sb_"):          # legacy JWT keys also go in Authorization
            self.s.headers["Authorization"] = f"Bearer {key}"

    def _rest(self, method, path, **kw):
        kw.setdefault("timeout", 30)
        r = self.s.request(method, f"{self.url}/rest/v1/{path}", **kw)
        if r.status_code >= 400:
            raise RuntimeError(f"Supabase {method} {path.split('?')[0]}: HTTP {r.status_code} {r.text[:200]}")
        return r

    def heartbeat(self):
        self._rest("POST", "agent_status",
                   json={"id": 1, "last_seen": iso(), "version": AGENT_VERSION},
                   headers={"Prefer": "resolution=merge-duplicates,return=minimal"})

    def claim(self, source):
        r = self._rest("GET", f"jobs?select=id,source&source=eq.{source}&status=eq.pending"
                              f"&order=requested_at.asc&limit=1")
        rows = r.json()
        if not rows:
            return None
        job_id = rows[0]["id"]
        r = self._rest("PATCH", f"jobs?id=eq.{job_id}&status=eq.pending",
                       json={"status": "running", "started_at": iso(),
                             "message": "Office PC picked this up", "progress": {"pct": 1}},
                       headers={"Prefer": "return=representation"})
        claimed = r.json()
        return claimed[0] if claimed else None

    def update(self, job_id, **fields):
        self._rest("PATCH", f"jobs?id=eq.{job_id}", json=fields, headers={"Prefer": "return=minimal"})

    def fail_interrupted(self):
        self._rest("PATCH", "jobs?status=eq.running",
                   json={"status": "error", "finished_at": iso(),
                         "error": "The office PC restarted during this refresh. Tap Refresh now again."},
                   headers={"Prefer": "return=minimal"})

    def upload(self, bucket_path, local_path):
        with open(local_path, "rb") as f:
            data = f.read()
        r = self.s.post(f"{self.url}/storage/v1/object/{BUCKET}/{bucket_path}", data=data, timeout=120,
                        headers={"Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                 "x-upsert": "true"})
        if r.status_code >= 400:
            raise RuntimeError(f"Upload failed: HTTP {r.status_code} {r.text[:200]}")

    def push_subscriptions(self):
        return self._rest("GET", "push_subscriptions?select=endpoint,subscription").json()

    def delete_push(self, endpoint):
        self._rest("DELETE", "push_subscriptions", params={"endpoint": f"eq.{endpoint}"},
                   headers={"Prefer": "return=minimal"})

    def cleanup(self, days):
        cutoff = (utcnow() - datetime.timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")  # no "+" (URLs turn it into a space)
        old = self._rest("GET", f"jobs?select=id,file_path&requested_at=lt.{cutoff}").json()
        paths = [o["file_path"] for o in old if o.get("file_path")]
        if paths:
            self.s.delete(f"{self.url}/storage/v1/object/{BUCKET}", json={"prefixes": paths}, timeout=60)
        if old:
            self._rest("DELETE", f"jobs?requested_at=lt.{cutoff}", headers={"Prefer": "return=minimal"})
            log.info(f"Cleanup: removed {len(old)} refreshes older than {days} days")


DB = None


class Reporter:
    """Sends live progress to the website, at most every ~2 seconds."""

    def __init__(self, job_id, labels):
        self.job_id = job_id
        self.progress = {"pct": 2, "branches": {l: {"state": "waiting"} for l in labels}}
        self.message = ""
        self.last = 0.0
        self.lock = threading.Lock()

    def branch(self, label, state, count=None):
        with self.lock:
            b = self.progress["branches"].setdefault(label, {})
            b["state"] = state
            if count is not None:
                b["count"] = count

    def set(self, pct=None, message=None, force=False):
        with self.lock:
            if pct is not None:
                self.progress["pct"] = max(1, min(99, int(pct)))
            if message is not None:
                self.message = message
            if not force and time.monotonic() - self.last < 2:
                return
            self.last = time.monotonic()
            payload = {"progress": json.loads(json.dumps(self.progress)), "message": self.message}
        try:
            DB.update(self.job_id, **payload)
        except Exception as e:
            log.info(f"(progress update skipped: {e})")


# ===========================================================================
# Shared Excel helpers
# ===========================================================================

def to_number(v):
    if isinstance(v, (int, float)):
        return v
    try:
        return float(str(v).replace("QAR", "").strip())
    except (TypeError, ValueError):
        return None


def template_names(path):
    ws = load_workbook(path).active
    return {str(ws.cell(r, 1).value).strip().lower()
            for r in range(2, ws.max_row + 1) if ws.cell(r, 1).value}


def build_table(path, labels, branch_cols, price_col):
    """Reads the finished Excel back into a small table for the website."""
    ws = load_workbook(path).active
    rows = []
    for r in range(2, ws.max_row + 1):
        name = ws.cell(r, 1).value
        if not name:
            continue
        stocks = []
        for c in branch_cols:
            v = ws.cell(r, c).value
            stocks.append(v if isinstance(v, (int, float)) and not isinstance(v, bool) else None)
        rows.append([str(name).strip(), str(ws.cell(r, 2).value or "").strip(),
                     to_number(ws.cell(r, price_col).value), stocks])
    return {"branches": labels, "rows": rows}


# ===========================================================================
# SNOONU (all logic and branches live in snoonu.py)
# ===========================================================================

def load_module(name):
    """Imports (or re-imports) snoonu.py / talabat.py so edits apply without a restart."""
    try:  # drop the cached compiled copy, so even a tiny quick edit is always picked up
        os.remove(importlib.util.cache_from_source(os.path.join(HERE, name + ".py")))
    except OSError:
        pass
    if name in sys.modules:
        return importlib.reload(sys.modules[name])
    return importlib.import_module(name)


def run_snoonu(job):
    S = load_module("snoonu")
    labels = [b["label"] for b in S.BRANCH_URLS]
    rep = Reporter(job["id"], labels)

    def on_branch(label, state, count):
        rep.branch(label, state, count)
        if state == "failed":
            log.info(f"  Snoonu {label}: FAILED")
        elif state == "done":
            log.info(f"  Snoonu {label}: {count} products")

    os.makedirs(OUT_DIR, exist_ok=True)
    out = os.path.join(OUT_DIR, f"Snoonu_Stock_{local_stamp()}.xlsx")
    summary = S.run(out, on_branch=on_branch, on_status=lambda pct, msg: rep.set(pct, msg, force=True))

    table = build_table(out, summary["labels"], summary["branch_cols"], price_col=summary["price_col"])
    table.update({"incomplete": list(summary["failed"]), "new_products": summary["new_products"],
                  "branch_errors": summary["failed"]})
    n = len(summary["labels"])
    return out, table, f"{n - len(summary['failed'])} of {n} branches, {len(table['rows'])} products"


# ===========================================================================
# TALABAT (all logic and branches live in talabat.py)
# ===========================================================================

_TALABAT_DONE_RE = re.compile(r"done:\s+(.+?)\s+\((\d+)/(\d+) categories\)")
_TALABAT_TICK_RE = re.compile(r"(\d+) pages fetched, (\d+)/(\d+) categories done")


def run_talabat(job):
    T = load_module("talabat")
    labels = [b["label"] for b in T.BRANCH_URLS]
    rep = Reporter(job["id"], labels)
    rep.set(2, "Starting a Talabat session", force=True)

    # Fresh counters for this run (the module keeps them between runs otherwise)
    T.RUN_START = time.time()
    T.LIMITER = T.AdaptiveRateLimiter(T.START_RATE, T.MIN_RATE, T.MAX_RATE)
    T._net["count"] = 0
    T.FEED_STATE.update({"on": False, "extra": {}, "broken": False})
    for b in T.BRANCH_URLS:
        b["_prefix"], b["_query"] = T.get_base_parts(b["url"])

    def hooked_print(*args, **kwargs):
        line = " ".join(str(a) for a in args)
        log.info("  talabat| " + line.strip())
        m = _TALABAT_DONE_RE.search(line)
        if m:
            rep.branch(m.group(1).strip(), "done")
            rep.set(8 + int(m.group(2)) / max(1, int(m.group(3))) * 82,
                    f"{m.group(1).strip()} finished", force=True)
            return
        m = _TALABAT_TICK_RE.search(line)
        if m:
            rep.set(8 + int(m.group(2)) / max(1, int(m.group(3))) * 82,
                    f"{m.group(1)} pages read, {m.group(2)} of {m.group(3)} category checks done")
            return
        if "quota reached" in line:
            wait = re.search(r"waiting (\d+)s", line)
            rep.set(message="Talabat asked us to slow down, pausing "
                    + (f"{wait.group(1)} seconds" if wait else "briefly"), force=True)
        elif "slow retry round" in line:
            rep.set(message="Re-checking a few pages that did not load", force=True)

    original_print = T.safe_print
    T.safe_print = hooked_print
    try:
        T.prepare()
        T.load_learned_speed()
        T.load_feed_settings()
        T.warm_up()
        rep.set(5, "Reading Talabat's category list", force=True)
        cat_names, all_keys, _ = T.read_category_tree()
        allow = T.load_allowlist()
        cat_keys = [k for k in all_keys if k in allow]
        mode_key = "fast" + ("-feed" + json.dumps(T.FEED_STATE["extra"], sort_keys=True)
                             if T.FEED_STATE["on"] else "")
        progress = T.load_progress(mode_key)
        for l in labels:
            rep.branch(l, "running")
        rep.set(8, f"Checking {len(cat_keys)} categories in {len(labels)} branches", force=True)

        state, incomplete = T.crawl(T.BRANCH_URLS, cat_keys, cat_names, progress)
        complete = {b["label"]: T.branch_products(state, b["label"], cat_keys)
                    for b in T.BRANCH_URLS if b["label"] not in incomplete}
        T.save_learned_speed()

        if not complete:
            raise RuntimeError("Talabat could not be read for any branch. Try again in a few minutes.")

        rep.set(93, "Filling your Excel template", force=True)
        os.makedirs(OUT_DIR, exist_ok=True)
        out = os.path.join(OUT_DIR, f"Talabat_Stock_{local_stamp()}.xlsx")
        T.OUTPUT_PATH = out
        T.write_results(T.TEMPLATE_PATH, complete, reset_columns=True, blank_labels=incomplete)
        if not incomplete:
            T.clear_progress()
    finally:
        T.safe_print = original_print

    for l in labels:
        if l in complete:
            rep.branch(l, "done", len(complete[l]))
        else:
            rep.branch(l, "failed")
    rep.set(97, "Preparing the results", force=True)

    before = template_names(T.TEMPLATE_PATH)
    table = build_table(out, labels, [b["_col"] for b in T.BRANCH_URLS], price_col=4)
    table.update({"incomplete": list(incomplete),
                  "new_products": [r[0] for r in table["rows"] if r[0].strip().lower() not in before]})
    return out, table, f"{len(complete)} of {len(labels)} branches, {len(table['rows'])} products"


# ===========================================================================
# FRUITY FRIENDS (all logic lives in fruity_friends_master.py, used unchanged)
# ===========================================================================

def _cell_num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _read_ff_sheet(F, wb, tag):
    """Reads back the session block just filled: {name: (price, [stock per branch])}, heads."""
    ws = F.find_sheet(wb, tag)
    lay = F.layout(ws)
    blk = lay["block"]
    return ws, lay, blk


def run_fruity(job):
    F = load_module(FRUITY_MODULE)
    session = ((job.get("options") or {}).get("session") or "").lower()
    if session not in ("morning", "evening"):
        raise RuntimeError("Pick Morning or Evening on the website, then tap Refresh again.")

    t_heads = [b["header"] for b in F.active(F.TALABAT_BRANCHES)]
    s_heads = [b["header"] for b in F.SNOONU_BRANCHES]
    labels = [f"{h} (T)" for h in t_heads] + [f"{h} (S)" for h in s_heads]
    rep = Reporter(job["id"], labels)
    best = [2]

    def bump(pct, msg=None, force=False):
        best[0] = max(best[0], pct)
        rep.set(best[0], msg, force=force)

    bump(2, f"Starting the {session} check", force=True)

    # run the script as if started with --morning / --evening, without any questions
    F.ARGS = []
    F.FORCE_MORNING = session == "morning"
    F.FORCE_EVENING = session == "evening"
    F.DISCOVER = False
    F.ONLY = None

    phase = {"name": "snoonu"}

    def hooked(*args, **kwargs):
        line = " ".join(str(a) for a in args).strip()
        if not line:
            return
        log.info("  fruity| " + line)
        if "=== TALABAT ===" in line:
            phase["name"] = "talabat"
            for h in t_heads:
                rep.branch(f"{h} (T)", "running")
            bump(28, "Talabat: reading the branch menus", force=True)
            return
        m = _TALABAT_DONE_RE.search(line)
        if m:
            rep.branch(f"{m.group(1).strip()} (T)", "done")
            bump(30 + int(m.group(2)) / max(1, int(m.group(3))) * 60, f"Talabat: {m.group(1).strip()} finished", force=True)
            return
        m = _TALABAT_TICK_RE.search(line)
        if m:
            bump(30 + int(m.group(2)) / max(1, int(m.group(3))) * 60,
                 f"Talabat: {m.group(1)} pages read, {m.group(2)} of {m.group(3)} checks done")
            return
        if "Talabat pushed back" in line or "waiting" in line and "Talabat" in line:
            rep.set(message="Talabat asked us to slow down, pausing briefly", force=True)
        elif "learning where Fruity Friends is" in line or "Re-learning" in line:
            rep.set(message="First run: searching the whole Talabat store once (20-30 min)", force=True)

    def safe_save(wb):
        tmp = F.WORKBOOK_PATH + ".tmp.xlsx"
        wb.save(tmp)
        try:
            os.replace(tmp, F.WORKBOOK_PATH)
        except PermissionError:
            raise RuntimeError(f"{os.path.basename(F.WORKBOOK_PATH)} is open in Excel on the office PC. "
                               f"Close it and tap Refresh again.")

    orig_snoonu, orig_talabat = F.crawl_snoonu, F.crawl_talabat

    def snoonu_wrapped():
        for h in s_heads:
            rep.branch(f"{h} (S)", "running")
        bump(5, "Snoonu: checking all branches", force=True)
        res = orig_snoonu()
        results, failed = res[0], set(res[1])
        for h in s_heads:
            if h in failed:
                rep.branch(f"{h} (S)", "failed")
            else:
                rep.branch(f"{h} (S)", "done", len(results.get(h, [])))
        bump(25, "Snoonu done", force=True)
        return res

    def talabat_wrapped():
        res = orig_talabat()
        results, failed = res[0], set(res[1])
        for h in t_heads:
            if h in failed:
                rep.branch(f"{h} (T)", "failed")
            else:
                rep.branch(f"{h} (T)", "done", len(results.get(h, [])))
        bump(92, "Writing the Excel", force=True)
        return res

    F.say = hooked
    F.safe_print = hooked
    F.save = safe_save
    F.crawl_snoonu = snoonu_wrapped
    F.crawl_talabat = talabat_wrapped
    try:
        code = F.main()
    except SystemExit as e:                     # the script stops with a message for config problems
        if e.code not in (None, 0, 2):
            raise RuntimeError(str(e.code))
        code = e.code

    bump(96, "Preparing the results", force=True)
    path = F.WORKBOOK_PATH
    wb = load_workbook(path)
    rows, order = {}, []
    t_failed, s_failed = [], []
    for tag, heads, offset, failed_out in (("t", t_heads, 0, t_failed), ("s", s_heads, len(t_heads), s_failed)):
        ws, lay, blk = _read_ff_sheet(F, wb, tag)
        start = blk["m0"] if session == "morning" else blk["e0"]
        col_of = {F.hkey(ws.cell(3, start + i).value): start + i for i in range(blk["n"])}
        cols = [col_of.get(F.hkey(h)) for h in heads]
        for r in lay["data"]:
            name = str(ws.cell(r, 1).value or "").strip()
            if not name:
                continue
            key = re.sub(r"[^a-z0-9]", "", name.lower())
            if key not in rows:
                rows[key] = [name, "", _cell_num(ws.cell(r, 2).value), [None] * len(labels)]
                order.append(key)
            for i, c in enumerate(cols):
                rows[key][3][offset + i] = _cell_num(ws.cell(r, c).value) if c else None
        for i, h in enumerate(heads):          # a branch with no number at all was not read
            if all(rows[k][3][offset + i] is None for k in order):
                failed_out.append(f"{h} ({tag.upper()})")

    os.makedirs(OUT_DIR, exist_ok=True)
    out = os.path.join(OUT_DIR, f"All_Stock_FruityFriends_{local_stamp()}_{session.capitalize()}.xlsx")
    shutil.copy2(path, out)

    table = {"branches": labels, "rows": [rows[k] for k in order],
             "incomplete": t_failed + s_failed, "new_products": [], "session": session}
    ok_t = len(t_heads) - len(t_failed)
    ok_s = len(s_heads) - len(s_failed)
    summary = (f"{session.capitalize()}: Talabat {ok_t}/{len(t_heads)}, Snoonu {ok_s}/{len(s_heads)} branches, "
               f"{len(order)} products")
    return out, table, summary


# ===========================================================================
# NINJA (all logic lives in ninja_stock.py, used unchanged)
# ===========================================================================

def _no_questions(*_a, **_k):
    raise EOFError        # the agent has no keyboard: makes the script stop with its own message


def _workbook_writable(path):
    try:
        with open(path, "r+b"):
            return True
    except PermissionError:
        return False
    except OSError:
        return True       # missing file etc. - the script reports that itself


def run_ninja(job):
    N = load_module(NINJA_MODULE)
    heads = [b["header"] for b in N.BRANCHES]
    rep = Reporter(job["id"], heads)
    if not _workbook_writable(N.WORKBOOK_PATH):
        raise RuntimeError(f"{os.path.basename(N.WORKBOOK_PATH)} is open in Excel on the office PC. "
                           f"Close it and tap Refresh again.")

    def hooked(*args, **kwargs):
        line = " ".join(str(a) for a in args).strip()
        if not line:
            return
        log.info("  ninja| " + line)
        if line.startswith("Finding Freshqa products"):
            rep.set(20, "Searching Ninja for Freshqa products", force=True)
        elif line.startswith("Using the Freshqa product list"):
            rep.set(30, "Reading stock in both branches", force=True)
        elif line.startswith("!!"):
            for h in heads:
                if line[2:].strip().startswith(h + ":"):
                    rep.branch(h, "failed")
        else:
            for h in heads:
                if line.startswith(h + " ") and "products in stock" in line:
                    rep.branch(h, "done")
                    rep.set(70, f"{h} read", force=True)

    for h in heads:
        rep.branch(h, "running")
    rep.set(5, "Connecting to Ninja", force=True)
    N.say = hooked
    N.input = _no_questions
    try:
        N.main()
    except SystemExit as e:
        if e.code not in (None, 0, 2):
            raise RuntimeError(str(e.code))

    rep.set(95, "Preparing the results", force=True)
    wb = load_workbook(N.WORKBOOK_PATH)
    ws = wb[N.SHEET_NAME] if N.SHEET_NAME in wb.sheetnames else wb.worksheets[0]
    head = {re.sub(r"[^a-z0-9]", "", str(ws.cell(5, c).value or "").lower()): c for c in range(1, ws.max_column + 1)}
    cols = [head.get(re.sub(r"[^a-z0-9]", "", h.lower())) for h in heads]
    rows = []
    r = N.FIRST_ROW
    while ws.cell(r, N.COL_NAME).value not in (None, ""):
        if str(ws.cell(r, N.COL_NOTE).value or "").strip().lower() != "ignore":
            rows.append([str(ws.cell(r, N.COL_NAME).value).strip(), str(ws.cell(r, N.COL_CAT).value or ""),
                         _cell_num(ws.cell(r, N.COL_PRICE).value),
                         [_cell_num(ws.cell(r, c).value) if c else None for c in cols]])
        r += 1
    failed = [h for i, h in enumerate(heads) if rows and all(x[3][i] is None for x in rows)]
    for i, h in enumerate(heads):
        if h not in failed:
            rep.branch(h, "done", sum(1 for x in rows if (x[3][i] or 0) > 0))

    os.makedirs(OUT_DIR, exist_ok=True)
    out = os.path.join(OUT_DIR, f"Ninja_Stock_{local_stamp()}.xlsx")
    shutil.copy2(N.WORKBOOK_PATH, out)
    table = {"branches": heads, "rows": rows, "incomplete": failed, "new_products": []}
    return out, table, f"{len(heads) - len(failed)} of {len(heads)} branches, {len(rows)} products"


# ===========================================================================
# Notifications to phones / PCs (Web Push)
# ===========================================================================

_push_warned = set()


def notify_devices(source, ok, text):
    if source not in NOTIFY_SOURCES:
        return
    if not os.path.exists(VAPID_PRIVATE_KEY_FILE):
        if "key" not in _push_warned:
            _push_warned.add("key")
            log.info("Notifications are off: run make_push_keys.py once to create vapid_private.pem")
        return
    try:
        from pywebpush import webpush, WebPushException
    except ImportError:
        if "lib" not in _push_warned:
            _push_warned.add("lib")
            log.info("Notifications are off: run  pip install pywebpush==2.5.0 py-vapid==1.9.4")
        return
    try:
        subs = DB.push_subscriptions()
    except Exception as e:
        log.info(f"(could not load notification devices: {e})")
        return
    name = SOURCE_NAMES.get(source, source.capitalize())
    payload = json.dumps({
        "title": f"{name} stock is ready" if ok else f"{name} refresh failed",
        "body": (f"{text}. Tap to open." if ok else (text or "Tap to see what happened."))[:200],
        "tag": f"{source}-done",
        "url": "./",
    })
    sent = removed = 0
    for s in subs:
        try:
            webpush(subscription_info=s["subscription"], data=payload,
                    vapid_private_key=VAPID_PRIVATE_KEY_FILE, vapid_claims={"sub": VAPID_CONTACT}, ttl=3600)
            sent += 1
        except WebPushException as e:
            code = getattr(getattr(e, "response", None), "status_code", None)
            if code in (404, 410):          # device unsubscribed or app removed
                try:
                    DB.delete_push(s["endpoint"])
                    removed += 1
                except Exception:
                    pass
            else:
                log.info(f"(notification to one device failed: {e})")
        except Exception as e:
            log.info(f"(notification to one device failed: {e})")
    if subs:
        log.info(f"{source}: notified {sent} device(s)" + (f", removed {removed} old" if removed else ""))


def push_check():
    """Writes one clear line at start-up about whether notifications can be sent."""
    if not os.path.exists(VAPID_PRIVATE_KEY_FILE):
        return log.info("Notifications: OFF - vapid_private.pem not found. Run: python make_push_keys.py")
    try:
        import pywebpush  # noqa: F401
    except ImportError:
        return log.info("Notifications: OFF - library missing. Run: pip install pywebpush==2.5.0 py-vapid==1.9.4")
    try:
        n = len(DB.push_subscriptions())
    except Exception as e:
        return log.info(f"Notifications: cannot read devices from Supabase ({e}). Did you run push_setup.sql?")
    log.info(f"Notifications: ready, {n} device(s) turned on")


# ===========================================================================
# Workers
# ===========================================================================

RUNNERS = {"snoonu": run_snoonu, "talabat": run_talabat, "fruity": run_fruity, "ninja": run_ninja}


def process(job):
    source = job["source"]
    log.info(f"{source}: refresh {job['id']} started")
    t0 = time.time()
    lock = SITE_LOCKS.get(source)
    try:
        if lock and not lock.acquire(blocking=False):
            other = "Fruity Friends" if source == "talabat" else "Talabat"
            DB.update(job["id"], message=f"Waiting for the {other} check to finish (both use Talabat)")
            lock.acquire()
        try:
            out, table, summary = RUNNERS[source](job)
        finally:
            if lock:
                lock.release()
        bucket_path = f"{source}/{os.path.basename(out)}"
        for attempt in range(3):
            try:
                DB.upload(bucket_path, out)
                break
            except Exception:
                if attempt == 2:
                    raise
                time.sleep(3)
        final = {"status": "done", "finished_at": iso(), "file_path": bucket_path,
                 "result": table, "message": summary,
                 "progress": {"pct": 100, "branches": {}}}
        for attempt in range(3):
            try:
                DB.update(job["id"], **final)
                break
            except Exception:
                if attempt == 2:
                    raise
                time.sleep(3)
        log.info(f"{source}: done in {time.time() - t0:.0f}s - {summary}")
        notify_devices(source, True, summary)
    except BaseException as e:   # talabat.py uses SystemExit for template problems
        msg = str(e) or e.__class__.__name__
        log.info(f"{source}: FAILED - {msg}\n{traceback.format_exc()}")
        try:
            DB.update(job["id"], status="error", finished_at=iso(), error=msg[:500])
        except Exception as e2:
            log.info(f"(could not report the error: {e2})")
        if not isinstance(e, KeyboardInterrupt):
            notify_devices(source, False, msg[:150])
        if isinstance(e, KeyboardInterrupt):
            raise


def worker(source):
    streak = 0
    while True:
        try:
            job = DB.claim(source)
            streak = 0
            if job:
                process(job)
                continue
        except Exception as e:
            streak += 1
            if streak in (1, 10) or streak % 100 == 0:
                log.info(f"{source}: connection problem ({streak}x): {e}")
        time.sleep(POLL_SECONDS if streak < 5 else 30)


def heartbeat_loop():
    last_cleanup = 0.0
    streak = 0
    while True:
        try:
            DB.heartbeat()
            if streak:
                log.info("Connection to Supabase is back")
            streak = 0
            if time.time() - last_cleanup > 12 * 3600:
                last_cleanup = time.time()
                DB.cleanup(KEEP_DAYS)
        except Exception as e:
            streak += 1
            if streak in (1, 10) or streak % 100 == 0:
                log.info(f"Heartbeat problem ({streak}x): {e}")
        time.sleep(HEARTBEAT_SECONDS)


def single_instance():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", 47812))
    except OSError:
        log.info("FreshQA agent is already running - this copy will exit.")
        sys.exit(0)
    return s


def main():
    global DB
    if "PASTE_" in SUPABASE_URL or "PASTE_" in SUPABASE_SERVICE_KEY:
        log.info("Set SUPABASE_URL and SUPABASE_SERVICE_KEY at the top of freshqa_agent.py first.")
        return
    for f in ("snoonu.py", "Snoonu_Stock.xlsx", "talabat.py", "Talabat_Temp.xlsx", FRUITY_MODULE + ".py", NINJA_MODULE + ".py"):
        if not os.path.exists(os.path.join(HERE, f)):
            log.info(f"Missing file next to the agent: {f}")
    _lock = single_instance()
    DB = Supabase(SUPABASE_URL, SUPABASE_SERVICE_KEY)
    try:
        DB.fail_interrupted()
    except Exception as e:
        log.info(f"(could not tidy old refreshes: {e})")
    log.info(f"FreshQA agent {AGENT_VERSION} started - waiting for 'Refresh now'.")
    push_check()

    threads = [threading.Thread(target=heartbeat_loop, name="beat", daemon=True)]
    threads += [threading.Thread(target=worker, args=(s,), name=s, daemon=True) for s in RUNNERS]
    for t in threads:
        t.start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        log.info("Agent stopped.")


if __name__ == "__main__":
    main()
