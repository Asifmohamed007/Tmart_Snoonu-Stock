"""
FreshQA Stock Agent  (runs quietly on the office PC)
-----------------------------------------------------
The website (Netlify) only shows the screens. This program does the real work:

  1. Every few seconds it asks Supabase: "has anyone tapped Refresh now?"
  2. If yes, it reads Snoonu or Talabat (your PC can - their sites block
     cloud servers), and sends live progress so the website can animate it.
  3. It fills your Excel template exactly like your Python scripts do,
     uploads the file to Supabase, and sends the stock table to the website.

Snoonu and Talabat can run at the same time (one worker each).
snoonu.py and talabat.py are re-loaded on every refresh, so edits to them
apply on the next tap of Refresh now - no restart needed.
Everything here - code, templates, keys - stays on this PC only.

FOLDER (put this file in the same folder as these):
    snoonu.py             Snoonu branches + logic (edit freely)
    talabat.py            Talabat branches + logic (edit freely)
    Talabat_Temp.xlsx     Talabat template
    Snoonu_Stock.xlsx     Snoonu template
    .talabat_*.json       Talabat's learned speed/categories (if you have them)

Requirements (install once):
    pip install requests openpyxl
"""

import os
import re
import sys
import json
import time
import importlib
import importlib.util
import socket
import logging
import datetime
import threading
import traceback

import requests
from openpyxl import load_workbook

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)                 # talabat.py uses relative paths for its files
sys.path.insert(0, HERE)

# ---------------------------------------------------------------------------
# CONFIGURE THESE TWO  (Supabase -> Project Settings -> API Keys)
# ---------------------------------------------------------------------------

SUPABASE_URL = "https://zraicjnfeycewtgufamd.supabase.co/rest/v1/"          # https://xxxx.supabase.co
SUPABASE_SERVICE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpyYWljam5mZXljZXd0Z3VmYW1kIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc5MTgwNTM5MiwiZXhwIjoyMTA3MzgxMzkyfQ.yG0ZX_Ly_P7LKql_XuokjAN9YCmgyEfpgeiT4HdTzx0"  # keep secret - PC only

# ---------------------------------------------------------------------------

AGENT_VERSION = "1.2"
POLL_SECONDS = 4
HEARTBEAT_SECONDS = 15
KEEP_DAYS = 60                 # older refreshes (and their files) are removed
OUT_DIR = os.path.join(HERE, "reports")

# Notifications ("Talabat is ready") - created by make_push_keys.py
VAPID_PRIVATE_KEY_FILE = os.path.join(HERE, "vapid_private.pem")
VAPID_CONTACT = "mailto:stock@freshqa.qa"   # any contact address, required by the push services
NOTIFY_SOURCES = {"talabat"}                # add "snoonu" here to be notified for Snoonu too
BUCKET = "reports"

# ---------------------------------------------------------------------------
# Logging (pythonw has no window, so everything goes to freshqa_agent.log)
# ---------------------------------------------------------------------------

logging.basicConfig(filename=os.path.join(HERE, "freshqa_agent.log"), level=logging.INFO,
                    format="%(asctime)s  %(threadName)-8s %(message)s")
log = logging.getLogger("agent")
if sys.stdout and hasattr(sys.stdout, "isatty") and sys.stdout.isatty():
    log.addHandler(logging.StreamHandler(sys.stdout))


def utcnow():
    return datetime.datetime.now(datetime.timezone.utc)


def iso(dt=None):
    return (dt or utcnow()).isoformat()


def local_stamp():
    return datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")


# ===========================================================================
# Supabase (plain REST, no extra libraries)
# ===========================================================================

class Supabase:
    def __init__(self, url, key):
        from urllib.parse import urlsplit
        parts = urlsplit(url.strip())
        # accept "https://x.supabase.co", ".../", ".../rest/v1/" etc.
        self.url = f"{parts.scheme}://{parts.netloc}" if parts.netloc else url.strip().rstrip("/")
        key = key.strip()
        self.key = key
        self.s = requests.Session()
        self.s.headers["apikey"] = key
        if not key.startswith("sb_"):          # legacy JWT keys also go in Authorization
            self.s.headers["Authorization"] = f"Bearer {key}"

    def _rest(self, method, path, **kw):
        kw.setdefault("timeout", 30)
        r = self.s.request(method, f"{self.url}/rest/v1/{path}", **kw)
        if r.status_code >= 400:
            raise RuntimeError(f"Supabase {method} {path.split('?')[0]}: HTTP {r.status_code} {r.text[:200]}")
        return r

    def heartbeat(self):
        self._rest("POST", "agent_status",
                   json={"id": 1, "last_seen": iso(), "version": AGENT_VERSION},
                   headers={"Prefer": "resolution=merge-duplicates,return=minimal"})

    def claim(self, source):
        r = self._rest("GET", f"jobs?select=id,source&source=eq.{source}&status=eq.pending"
                              f"&order=requested_at.asc&limit=1")
        rows = r.json()
        if not rows:
            return None
        job_id = rows[0]["id"]
        r = self._rest("PATCH", f"jobs?id=eq.{job_id}&status=eq.pending",
                       json={"status": "running", "started_at": iso(),
                             "message": "Office PC picked this up", "progress": {"pct": 1}},
                       headers={"Prefer": "return=representation"})
        claimed = r.json()
        return claimed[0] if claimed else None

    def update(self, job_id, **fields):
        self._rest("PATCH", f"jobs?id=eq.{job_id}", json=fields, headers={"Prefer": "return=minimal"})

    def fail_interrupted(self):
        self._rest("PATCH", "jobs?status=eq.running",
                   json={"status": "error", "finished_at": iso(),
                         "error": "The office PC restarted during this refresh. Tap Refresh now again."},
                   headers={"Prefer": "return=minimal"})

    def upload(self, bucket_path, local_path):
        with open(local_path, "rb") as f:
            data = f.read()
        r = self.s.post(f"{self.url}/storage/v1/object/{BUCKET}/{bucket_path}", data=data, timeout=120,
                        headers={"Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                 "x-upsert": "true"})
        if r.status_code >= 400:
            raise RuntimeError(f"Upload failed: HTTP {r.status_code} {r.text[:200]}")

    def push_subscriptions(self):
        return self._rest("GET", "push_subscriptions?select=endpoint,subscription").json()

    def delete_push(self, endpoint):
        self._rest("DELETE", "push_subscriptions", params={"endpoint": f"eq.{endpoint}"},
                   headers={"Prefer": "return=minimal"})

    def cleanup(self, days):
        cutoff = (utcnow() - datetime.timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")  # no "+" (URLs turn it into a space)
        old = self._rest("GET", f"jobs?select=id,file_path&requested_at=lt.{cutoff}").json()
        paths = [o["file_path"] for o in old if o.get("file_path")]
        if paths:
            self.s.delete(f"{self.url}/storage/v1/object/{BUCKET}", json={"prefixes": paths}, timeout=60)
        if old:
            self._rest("DELETE", f"jobs?requested_at=lt.{cutoff}", headers={"Prefer": "return=minimal"})
            log.info(f"Cleanup: removed {len(old)} refreshes older than {days} days")


DB = None


class Reporter:
    """Sends live progress to the website, at most every ~2 seconds."""

    def __init__(self, job_id, labels):
        self.job_id = job_id
        self.progress = {"pct": 2, "branches": {l: {"state": "waiting"} for l in labels}}
        self.message = ""
        self.last = 0.0
        self.lock = threading.Lock()

    def branch(self, label, state, count=None):
        with self.lock:
            b = self.progress["branches"].setdefault(label, {})
            b["state"] = state
            if count is not None:
                b["count"] = count

    def set(self, pct=None, message=None, force=False):
        with self.lock:
            if pct is not None:
                self.progress["pct"] = max(1, min(99, int(pct)))
            if message is not None:
                self.message = message
            if not force and time.monotonic() - self.last < 2:
                return
            self.last = time.monotonic()
            payload = {"progress": json.loads(json.dumps(self.progress)), "message": self.message}
        try:
            DB.update(self.job_id, **payload)
        except Exception as e:
            log.info(f"(progress update skipped: {e})")


# ===========================================================================
# Shared Excel helpers
# ===========================================================================

def to_number(v):
    if isinstance(v, (int, float)):
        return v
    try:
        return float(str(v).replace("QAR", "").strip())
    except (TypeError, ValueError):
        return None


def template_names(path):
    ws = load_workbook(path).active
    return {str(ws.cell(r, 1).value).strip().lower()
            for r in range(2, ws.max_row + 1) if ws.cell(r, 1).value}


def build_table(path, labels, branch_cols, price_col):
    """Reads the finished Excel back into a small table for the website."""
    ws = load_workbook(path).active
    rows = []
    for r in range(2, ws.max_row + 1):
        name = ws.cell(r, 1).value
        if not name:
            continue
        stocks = []
        for c in branch_cols:
            v = ws.cell(r, c).value
            stocks.append(v if isinstance(v, (int, float)) and not isinstance(v, bool) else None)
        rows.append([str(name).strip(), str(ws.cell(r, 2).value or "").strip(),
                     to_number(ws.cell(r, price_col).value), stocks])
    return {"branches": labels, "rows": rows}


# ===========================================================================
# SNOONU (all logic and branches live in snoonu.py)
# ===========================================================================

def load_module(name):
    """Imports (or re-imports) snoonu.py / talabat.py so edits apply without a restart."""
    try:  # drop the cached compiled copy, so even a tiny quick edit is always picked up
        os.remove(importlib.util.cache_from_source(os.path.join(HERE, name + ".py")))
    except OSError:
        pass
    if name in sys.modules:
        return importlib.reload(sys.modules[name])
    return importlib.import_module(name)


def run_snoonu(job):
    S = load_module("snoonu")
    labels = [b["label"] for b in S.BRANCH_URLS]
    rep = Reporter(job["id"], labels)

    def on_branch(label, state, count):
        rep.branch(label, state, count)
        if state == "failed":
            log.info(f"  Snoonu {label}: FAILED")
        elif state == "done":
            log.info(f"  Snoonu {label}: {count} products")

    os.makedirs(OUT_DIR, exist_ok=True)
    out = os.path.join(OUT_DIR, f"Snoonu_Stock_{local_stamp()}.xlsx")
    summary = S.run(out, on_branch=on_branch, on_status=lambda pct, msg: rep.set(pct, msg, force=True))

    table = build_table(out, summary["labels"], summary["branch_cols"], price_col=summary["price_col"])
    table.update({"incomplete": list(summary["failed"]), "new_products": summary["new_products"],
                  "branch_errors": summary["failed"]})
    n = len(summary["labels"])
    return out, table, f"{n - len(summary['failed'])} of {n} branches, {len(table['rows'])} products"


# ===========================================================================
# TALABAT (all logic and branches live in talabat.py)
# ===========================================================================

_TALABAT_DONE_RE = re.compile(r"done:\s+(.+?)\s+\((\d+)/(\d+) categories\)")
_TALABAT_TICK_RE = re.compile(r"(\d+) pages fetched, (\d+)/(\d+) categories done")


def run_talabat(job):
    T = load_module("talabat")
    labels = [b["label"] for b in T.BRANCH_URLS]
    rep = Reporter(job["id"], labels)
    rep.set(2, "Starting a Talabat session", force=True)

    # Fresh counters for this run (the module keeps them between runs otherwise)
    T.RUN_START = time.time()
    T.LIMITER = T.AdaptiveRateLimiter(T.START_RATE, T.MIN_RATE, T.MAX_RATE)
    T._net["count"] = 0
    T.FEED_STATE.update({"on": False, "extra": {}, "broken": False})
    for b in T.BRANCH_URLS:
        b["_prefix"], b["_query"] = T.get_base_parts(b["url"])

    def hooked_print(*args, **kwargs):
        line = " ".join(str(a) for a in args)
        log.info("  talabat| " + line.strip())
        m = _TALABAT_DONE_RE.search(line)
        if m:
            rep.branch(m.group(1).strip(), "done")
            rep.set(8 + int(m.group(2)) / max(1, int(m.group(3))) * 82,
                    f"{m.group(1).strip()} finished", force=True)
            return
        m = _TALABAT_TICK_RE.search(line)
        if m:
            rep.set(8 + int(m.group(2)) / max(1, int(m.group(3))) * 82,
                    f"{m.group(1)} pages read, {m.group(2)} of {m.group(3)} category checks done")
            return
        if "quota reached" in line:
            wait = re.search(r"waiting (\d+)s", line)
            rep.set(message="Talabat asked us to slow down, pausing "
                    + (f"{wait.group(1)} seconds" if wait else "briefly"), force=True)
        elif "slow retry round" in line:
            rep.set(message="Re-checking a few pages that did not load", force=True)

    original_print = T.safe_print
    T.safe_print = hooked_print
    try:
        T.prepare()
        T.load_learned_speed()
        T.load_feed_settings()
        T.warm_up()
        rep.set(5, "Reading Talabat's category list", force=True)
        cat_names, all_keys, _ = T.read_category_tree()
        allow = T.load_allowlist()
        cat_keys = [k for k in all_keys if k in allow]
        mode_key = "fast" + ("-feed" + json.dumps(T.FEED_STATE["extra"], sort_keys=True)
                             if T.FEED_STATE["on"] else "")
        progress = T.load_progress(mode_key)
        for l in labels:
            rep.branch(l, "running")
        rep.set(8, f"Checking {len(cat_keys)} categories in {len(labels)} branches", force=True)

        state, incomplete = T.crawl(T.BRANCH_URLS, cat_keys, cat_names, progress)
        complete = {b["label"]: T.branch_products(state, b["label"], cat_keys)
                    for b in T.BRANCH_URLS if b["label"] not in incomplete}
        T.save_learned_speed()

        if not complete:
            raise RuntimeError("Talabat could not be read for any branch. Try again in a few minutes.")

        rep.set(93, "Filling your Excel template", force=True)
        os.makedirs(OUT_DIR, exist_ok=True)
        out = os.path.join(OUT_DIR, f"Talabat_Stock_{local_stamp()}.xlsx")
        T.OUTPUT_PATH = out
        T.write_results(T.TEMPLATE_PATH, complete, reset_columns=True, blank_labels=incomplete)
        if not incomplete:
            T.clear_progress()
    finally:
        T.safe_print = original_print

    for l in labels:
        if l in complete:
            rep.branch(l, "done", len(complete[l]))
        else:
            rep.branch(l, "failed")
    rep.set(97, "Preparing the results", force=True)

    before = template_names(T.TEMPLATE_PATH)
    table = build_table(out, labels, [b["_col"] for b in T.BRANCH_URLS], price_col=4)
    table.update({"incomplete": list(incomplete),
                  "new_products": [r[0] for r in table["rows"] if r[0].strip().lower() not in before]})
    return out, table, f"{len(complete)} of {len(labels)} branches, {len(table['rows'])} products"


# ===========================================================================
# Notifications to phones / PCs (Web Push)
# ===========================================================================

_push_warned = set()


def notify_devices(source, ok, text):
    if source not in NOTIFY_SOURCES:
        return
    if not os.path.exists(VAPID_PRIVATE_KEY_FILE):
        if "key" not in _push_warned:
            _push_warned.add("key")
            log.info("Notifications are off: run make_push_keys.py once to create vapid_private.pem")
        return
    try:
        from pywebpush import webpush, WebPushException
    except ImportError:
        if "lib" not in _push_warned:
            _push_warned.add("lib")
            log.info("Notifications are off: run  pip install pywebpush==2.5.0 py-vapid==1.9.4")
        return
    try:
        subs = DB.push_subscriptions()
    except Exception as e:
        log.info(f"(could not load notification devices: {e})")
        return
    name = source.capitalize()
    payload = json.dumps({
        "title": f"{name} stock is ready" if ok else f"{name} refresh failed",
        "body": (f"{text}. Tap to open." if ok else (text or "Tap to see what happened."))[:200],
        "tag": f"{source}-done",
        "url": "./",
    })
    sent = removed = 0
    for s in subs:
        try:
            webpush(subscription_info=s["subscription"], data=payload,
                    vapid_private_key=VAPID_PRIVATE_KEY_FILE, vapid_claims={"sub": VAPID_CONTACT}, ttl=3600)
            sent += 1
        except WebPushException as e:
            code = getattr(getattr(e, "response", None), "status_code", None)
            if code in (404, 410):          # device unsubscribed or app removed
                try:
                    DB.delete_push(s["endpoint"])
                    removed += 1
                except Exception:
                    pass
            else:
                log.info(f"(notification to one device failed: {e})")
        except Exception as e:
            log.info(f"(notification to one device failed: {e})")
    if subs:
        log.info(f"{source}: notified {sent} device(s)" + (f", removed {removed} old" if removed else ""))


# ===========================================================================
# Workers
# ===========================================================================

RUNNERS = {"snoonu": run_snoonu, "talabat": run_talabat}


def process(job):
    source = job["source"]
    log.info(f"{source}: refresh {job['id']} started")
    t0 = time.time()
    try:
        out, table, summary = RUNNERS[source](job)
        bucket_path = f"{source}/{os.path.basename(out)}"
        for attempt in range(3):
            try:
                DB.upload(bucket_path, out)
                break
            except Exception:
                if attempt == 2:
                    raise
                time.sleep(3)
        final = {"status": "done", "finished_at": iso(), "file_path": bucket_path,
                 "result": table, "message": summary,
                 "progress": {"pct": 100, "branches": {}}}
        for attempt in range(3):
            try:
                DB.update(job["id"], **final)
                break
            except Exception:
                if attempt == 2:
                    raise
                time.sleep(3)
        log.info(f"{source}: done in {time.time() - t0:.0f}s - {summary}")
        notify_devices(source, True, summary)
    except BaseException as e:   # talabat.py uses SystemExit for template problems
        msg = str(e) or e.__class__.__name__
        log.info(f"{source}: FAILED - {msg}\n{traceback.format_exc()}")
        try:
            DB.update(job["id"], status="error", finished_at=iso(), error=msg[:500])
        except Exception as e2:
            log.info(f"(could not report the error: {e2})")
        if not isinstance(e, KeyboardInterrupt):
            notify_devices(source, False, msg[:150])
        if isinstance(e, KeyboardInterrupt):
            raise


def worker(source):
    streak = 0
    while True:
        try:
            job = DB.claim(source)
            streak = 0
            if job:
                process(job)
                continue
        except Exception as e:
            streak += 1
            if streak in (1, 10) or streak % 100 == 0:
                log.info(f"{source}: connection problem ({streak}x): {e}")
        time.sleep(POLL_SECONDS if streak < 5 else 30)


def heartbeat_loop():
    last_cleanup = 0.0
    streak = 0
    while True:
        try:
            DB.heartbeat()
            if streak:
                log.info("Connection to Supabase is back")
            streak = 0
            if time.time() - last_cleanup > 12 * 3600:
                last_cleanup = time.time()
                DB.cleanup(KEEP_DAYS)
        except Exception as e:
            streak += 1
            if streak in (1, 10) or streak % 100 == 0:
                log.info(f"Heartbeat problem ({streak}x): {e}")
        time.sleep(HEARTBEAT_SECONDS)


def single_instance():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", 47812))
    except OSError:
        log.info("FreshQA agent is already running - this copy will exit.")
        sys.exit(0)
    return s


def main():
    global DB
    if "PASTE_" in SUPABASE_URL or "PASTE_" in SUPABASE_SERVICE_KEY:
        log.info("Set SUPABASE_URL and SUPABASE_SERVICE_KEY at the top of freshqa_agent.py first.")
        return
    for f in ("snoonu.py", "Snoonu_Stock.xlsx", "talabat.py", "Talabat_Temp.xlsx"):
        if not os.path.exists(os.path.join(HERE, f)):
            log.info(f"Missing file next to the agent: {f}")
    _lock = single_instance()
    DB = Supabase(SUPABASE_URL, SUPABASE_SERVICE_KEY)
    try:
        DB.fail_interrupted()
    except Exception as e:
        log.info(f"(could not tidy old refreshes: {e})")
    log.info(f"FreshQA agent {AGENT_VERSION} started - waiting for 'Refresh now'.")

    threads = [threading.Thread(target=heartbeat_loop, name="beat", daemon=True)]
    threads += [threading.Thread(target=worker, args=(s,), name=s, daemon=True) for s in RUNNERS]
    for t in threads:
        t.start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        log.info("Agent stopped.")


if __name__ == "__main__":
    main()
