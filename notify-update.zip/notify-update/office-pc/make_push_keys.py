"""
Run ONCE on the office PC to create the notification keys:

    pip install pywebpush==2.5.0 py-vapid==1.9.4
    python make_push_keys.py

It creates vapid_private.pem in this folder (keep it here, never share it)
and prints the PUBLIC key to paste into index.html (VAPID_PUBLIC_KEY).
"""
import base64
import os
import sys

from cryptography.hazmat.primitives import serialization
from py_vapid import Vapid

HERE = os.path.dirname(os.path.abspath(__file__))
PEM = os.path.join(HERE, "vapid_private.pem")

if os.path.exists(PEM):
    v = Vapid.from_file(PEM)
    print("vapid_private.pem already exists - keeping it (making a new one would switch off every device).")
else:
    v = Vapid()
    v.generate_keys()
    v.save_key(PEM)
    print("Created vapid_private.pem  (keep it in this folder, do not share it)")

raw = v.public_key.public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
public = base64.urlsafe_b64encode(raw).rstrip(b"=").decode()
print("\nPaste this into index.html as VAPID_PUBLIC_KEY:\n")
print(public)
print()
sys.exit(0)
