-- =====================================================================
-- FreshQA Stock - notifications add-on
-- Supabase -> SQL Editor -> New query -> paste ALL of this -> Run.
-- Safe to run again.
-- =====================================================================

-- Devices that asked to be notified when Talabat finishes
create table if not exists public.push_subscriptions (
  endpoint      text primary key,
  subscription  jsonb not null,
  user_agent    text,
  created_at    timestamptz not null default now()
);

-- Nobody can read this table from the website (only the office PC's secret key)
alter table public.push_subscriptions enable row level security;
revoke all on public.push_subscriptions from anon, authenticated;

-- The website may only add / remove ITS OWN device
create or replace function public.save_push_subscription(p_sub jsonb, p_ua text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_sub is null or coalesce(p_sub->>'endpoint', '') !~ '^https://' then
    raise exception 'Invalid subscription';
  end if;
  if length(p_sub::text) > 4000 then
    raise exception 'Subscription too large';
  end if;
  if (select count(*) from public.push_subscriptions) >= 300
     and not exists (select 1 from public.push_subscriptions where endpoint = p_sub->>'endpoint') then
    raise exception 'Too many devices registered';
  end if;
  insert into public.push_subscriptions (endpoint, subscription, user_agent)
  values (p_sub->>'endpoint', p_sub, left(p_ua, 300))
  on conflict (endpoint) do update
    set subscription = excluded.subscription, user_agent = excluded.user_agent;
end;
$$;

create or replace function public.delete_push_subscription(p_endpoint text)
returns void
language sql
security definer
set search_path = public
as $$
  delete from public.push_subscriptions where endpoint = p_endpoint;
$$;

revoke all on function public.save_push_subscription(jsonb, text) from public;
revoke all on function public.delete_push_subscription(text) from public;
grant execute on function public.save_push_subscription(jsonb, text) to anon, authenticated;
grant execute on function public.delete_push_subscription(text) to anon, authenticated;
