# FreshQA Stock Radar – setup (about 20 minutes, all free)

```
website/     -> goes on Netlify (what colleagues see)
supabase/    -> run once in Supabase (database + file storage)
office-pc/   -> stays on the office PC (the engine – never shared)
```

## 1. Supabase (database)

1. Go to supabase.com, sign in, click **New project**. Name it `freshqa-stock`, choose a region close to Qatar (e.g. Frankfurt or Mumbai), set any database password, click **Create**.
2. Left menu: **SQL Editor → New query**. Paste everything from `supabase/supabase_setup.sql` and click **Run**. You should see "Success".
3. Left menu: **Project Settings → API Keys**. If you see a **Legacy API keys** tab, use that one. Copy three things:
   - **Project URL** (Project Settings → Data API, looks like `https://abcd.supabase.co`)
   - **anon / publishable** key → goes in the website
   - **service_role / secret** key → goes ONLY on the office PC. Never put it in the website.

## 2. Office PC (the engine)

1. Copy the `office-pc` folder to the PC, e.g. `C:\FreshQA\`.
   If you already have `.talabat_speed_v5.json`, `.talabat_relevant_subcategories.json` or `.talabat_feed.json` next to your old talabat.py, copy them into this folder too, so Talabat starts at its learned speed.
2. Open `freshqa_agent.py` in Notepad and paste at the top:
   ```
   SUPABASE_URL = "https://abcd.supabase.co"
   SUPABASE_SERVICE_KEY = "your service_role / secret key"
   ```
3. Install once (cmd): `pip install requests openpyxl`
4. Stop the old Snoonu agent: Task Manager → end **pythonw.exe**, and delete the old
   "Start Snoonu Agent" shortcut from the Startup folder (`Win + R` → `shell:startup`).
5. Double-click **Start FreshQA Agent.bat** (runs silently).
6. Auto-start: `Win + R` → `shell:startup` → right-click inside → **Paste shortcut** of `Start FreshQA Agent.bat`.

Problems? Open `freshqa_agent.log` in the same folder.

## 3. Netlify (the website)

1. Open `website/index.html` in Notepad and fill in at the top:
   ```
   SUPABASE_URL: "https://abcd.supabase.co",
   SUPABASE_ANON_KEY: "your anon / publishable key"
   ```
2. Go to **app.netlify.com/drop** (sign in) and drag the whole `website` folder onto the page.
3. **Site configuration → Change site name** → e.g. `freshqa-stock` → your link is `https://freshqa-stock.netlify.app`.
4. To update later: Netlify → your site → **Deploys** → drag the folder again. The link stays the same.

## Using it

Open the link (phone or PC). The pill at the top shows **Office PC online**.
Pick Snoonu or Talabat → **Refresh now** → watch the branches light up → **Download Excel**.
On a phone: browser menu → **Add to Home screen** to get an app icon.

Changing branch URLs: edit `SNOONU_BRANCHES` in `freshqa_agent.py`, or `BRANCH_URLS` in `talabat.py`
(as before), then restart the agent. If you add or rename a branch, also update the
branch names in `SOURCES` near the bottom of `website/index.html` (only used before the first refresh).
