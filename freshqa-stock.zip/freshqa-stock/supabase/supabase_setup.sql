-- =====================================================================
-- FreshQA Stock Radar - Supabase setup
-- Paste ALL of this into Supabase -> SQL Editor -> New query -> Run.
-- Safe to run again (it skips what already exists).
-- =====================================================================

-- 1. Refresh jobs: one row per "Refresh now" tap ------------------------
create table if not exists public.jobs (
  id            uuid primary key default gen_random_uuid(),
  source        text not null check (source in ('snoonu', 'talabat')),
  status        text not null default 'pending'
                check (status in ('pending', 'running', 'done', 'error')),
  requested_at  timestamptz not null default now(),
  started_at    timestamptz,
  finished_at   timestamptz,
  message       text,
  progress      jsonb not null default '{}'::jsonb,   -- live progress for the page
  result        jsonb,                                -- stock table shown on the page
  file_path     text,                                 -- Excel file in the "reports" bucket
  error         text
);
create index if not exists jobs_source_requested on public.jobs (source, requested_at desc);
create index if not exists jobs_source_finished  on public.jobs (source, finished_at desc);

-- 2. Office PC heartbeat (one row) -------------------------------------
create table if not exists public.agent_status (
  id         int primary key default 1 check (id = 1),
  last_seen  timestamptz,
  version    text
);
insert into public.agent_status (id) values (1) on conflict (id) do nothing;

-- 3. Security: the website can READ, but never write directly ------------
alter table public.jobs         enable row level security;
alter table public.agent_status enable row level security;

drop policy if exists "website reads jobs" on public.jobs;
create policy "website reads jobs" on public.jobs
  for select to anon, authenticated using (true);

drop policy if exists "website reads agent status" on public.agent_status;
create policy "website reads agent status" on public.agent_status
  for select to anon, authenticated using (true);

revoke insert, update, delete on public.jobs         from anon, authenticated;
revoke insert, update, delete on public.agent_status from anon, authenticated;

-- 4. The ONLY thing the website can do: ask for a refresh ---------------
--    If a refresh for that source is already waiting or running, it returns
--    that one instead of creating another (so 10 taps = 1 refresh).
create or replace function public.request_refresh(p_source text)
returns public.jobs
language plpgsql
security definer
set search_path = public
as $$
declare
  j public.jobs;
begin
  if p_source not in ('snoonu', 'talabat') then
    raise exception 'Unknown source %', p_source;
  end if;

  select * into j
  from public.jobs
  where source = p_source
    and (status = 'pending'
         or (status = 'running' and started_at > now() - interval '45 minutes'))
  order by requested_at desc
  limit 1;

  if found then
    return j;
  end if;

  insert into public.jobs (source) values (p_source) returning * into j;
  return j;
end;
$$;

revoke all on function public.request_refresh(text) from public;
grant execute on function public.request_refresh(text) to anon, authenticated;

-- 5. Live updates to the website ---------------------------------------
do $$
begin
  begin
    alter publication supabase_realtime add table public.jobs;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.agent_status;
  exception when duplicate_object then null;
  end;
end $$;

-- 6. File storage for the Excel reports (public download links) --------
insert into storage.buckets (id, name, public)
values ('reports', 'reports', true)
on conflict (id) do update set public = true;
