"""
FreshQA Stock Agent  (runs quietly on the office PC)
-----------------------------------------------------
The website (Netlify) only shows the screens. This program does the real work:

  1. Every few seconds it asks Supabase: "has anyone tapped Refresh now?"
  2. If yes, it reads Snoonu or Talabat (your PC can - their sites block
     cloud servers), and sends live progress so the website can animate it.
  3. It fills your Excel template exactly like your Python scripts do,
     uploads the file to Supabase, and sends the stock table to the website.

Snoonu and Talabat can run at the same time (one worker each).
Everything here - code, templates, keys - stays on this PC only.

FOLDER (put this file in the same folder as these):
    talabat.py            your existing Talabat script (unchanged)
    Talabat_Temp.xlsx     Talabat template
    Snoonu_Stock.xlsx     Snoonu template
    .talabat_*.json       Talabat's learned speed/categories (if you have them)

Requirements (install once):
    pip install requests openpyxl
"""

import os
import re
import sys
import json
import time
import copy
import socket
import logging
import datetime
import threading
import traceback

import requests
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)                 # talabat.py uses relative paths for its files
sys.path.insert(0, HERE)

# ---------------------------------------------------------------------------
# CONFIGURE THESE TWO  (Supabase -> Project Settings -> API Keys)
# ---------------------------------------------------------------------------

SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL"          # https://xxxx.supabase.co
SUPABASE_SERVICE_KEY = "PASTE_YOUR_SERVICE_ROLE_OR_SECRET_KEY"  # keep secret - PC only

# ---------------------------------------------------------------------------

AGENT_VERSION = "1.0"
POLL_SECONDS = 4
HEARTBEAT_SECONDS = 15
KEEP_DAYS = 60                 # older refreshes (and their files) are removed
OUT_DIR = os.path.join(HERE, "reports")
BUCKET = "reports"

SNOONU_TEMPLATE = "Snoonu_Stock.xlsx"
SNOONU_BRANCHES = [  # order = template columns D..K
    {"label": "Al Saad",       "url": "https://snoonu.com/groceries/snoomart/0?type=2&branchId=6111786629130af8eac70c07&categoryId=64c77ad21040631725d46eef"},
    {"label": "Umm Salal Ali", "url": "https://snoonu.com/groceries/snoomart/0?type=2&branchId=61b9900af970fcabad7791c5&categoryId=64c77ad21040631725d46eef"},
    {"label": "Lusail",        "url": "https://snoonu.com/groceries/snoomart/0?type=2&branchId=61da7839175b0237f0cb8079&categoryId=64c77ad21040631725d46eef"},
    {"label": "Industry Area", "url": "https://snoonu.com/groceries/snoomart/0?type=2&branchId=61da789a9132f2fca9230030&categoryId=64c77ad21040631725d46eef"},
    {"label": "Wakra",         "url": "https://snoonu.com/groceries/snoomart/0?type=2&branchId=66040dea3f41b3cc9af44134&categoryId=64c77ad21040631725d46eef"},
    {"label": "Bani Hajer",    "url": "https://snoonu.com/groceries/snoomart/0?type=2&branchId=68a465fe8876a0a4ba8c8015&categoryId=64c77ad21040631725d46eef"},
    {"label": "Al Khor",       "url": "https://snoonu.com/groceries/snoomart/0?type=2&branchId=695b506d5d7f865dee68164f&categoryId=64c77ad21040631725d46eef"},
    {"label": "Shahaniya",     "url": "https://snoonu.com/groceries/snoomart/0?type=2&branchId=69ef5bb8003c6ac7181883b6&categoryId=64c77ad21040631725d46eef"},
]
SNOONU_FIRST_BRANCH_COL = 4    # D
SNOONU_TOTAL_COL = 12          # L
SNOONU_HELPER_COL = 13         # M
SNOONU_FILL_COL = 14           # N
SNOONU_LAST_COL = 15           # O
SNOONU_DELAY = 1.5

BROWSER_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
    "Accept-Language": "en-US,en;q=0.9",
}
NEXT_DATA_RE = re.compile(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', re.DOTALL)

# ---------------------------------------------------------------------------
# Logging (pythonw has no window, so everything goes to freshqa_agent.log)
# ---------------------------------------------------------------------------

logging.basicConfig(filename=os.path.join(HERE, "freshqa_agent.log"), level=logging.INFO,
                    format="%(asctime)s  %(threadName)-8s %(message)s")
log = logging.getLogger("agent")
if sys.stdout and hasattr(sys.stdout, "isatty") and sys.stdout.isatty():
    log.addHandler(logging.StreamHandler(sys.stdout))


def utcnow():
    return datetime.datetime.now(datetime.timezone.utc)


def iso(dt=None):
    return (dt or utcnow()).isoformat()


def local_stamp():
    return datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")


# ===========================================================================
# Supabase (plain REST, no extra libraries)
# ===========================================================================

class Supabase:
    def __init__(self, url, key):
        from urllib.parse import urlsplit
        parts = urlsplit(url.strip())
        # accept "https://x.supabase.co", ".../", ".../rest/v1/" etc.
        self.url = f"{parts.scheme}://{parts.netloc}" if parts.netloc else url.strip().rstrip("/")
        key = key.strip()
        self.key = key
        self.s = requests.Session()
        self.s.headers["apikey"] = key
        if not key.startswith("sb_"):          # legacy JWT keys also go in Authorization
            self.s.headers["Authorization"] = f"Bearer {key}"

    def _rest(self, method, path, **kw):
        kw.setdefault("timeout", 30)
        r = self.s.request(method, f"{self.url}/rest/v1/{path}", **kw)
        if r.status_code >= 400:
            raise RuntimeError(f"Supabase {method} {path.split('?')[0]}: HTTP {r.status_code} {r.text[:200]}")
        return r

    def heartbeat(self):
        self._rest("POST", "agent_status",
                   json={"id": 1, "last_seen": iso(), "version": AGENT_VERSION},
                   headers={"Prefer": "resolution=merge-duplicates,return=minimal"})

    def claim(self, source):
        r = self._rest("GET", f"jobs?select=id,source&source=eq.{source}&status=eq.pending"
                              f"&order=requested_at.asc&limit=1")
        rows = r.json()
        if not rows:
            return None
        job_id = rows[0]["id"]
        r = self._rest("PATCH", f"jobs?id=eq.{job_id}&status=eq.pending",
                       json={"status": "running", "started_at": iso(),
                             "message": "Office PC picked this up", "progress": {"pct": 1}},
                       headers={"Prefer": "return=representation"})
        claimed = r.json()
        return claimed[0] if claimed else None

    def update(self, job_id, **fields):
        self._rest("PATCH", f"jobs?id=eq.{job_id}", json=fields, headers={"Prefer": "return=minimal"})

    def fail_interrupted(self):
        self._rest("PATCH", "jobs?status=eq.running",
                   json={"status": "error", "finished_at": iso(),
                         "error": "The office PC restarted during this refresh. Tap Refresh now again."},
                   headers={"Prefer": "return=minimal"})

    def upload(self, bucket_path, local_path):
        with open(local_path, "rb") as f:
            data = f.read()
        r = self.s.post(f"{self.url}/storage/v1/object/{BUCKET}/{bucket_path}", data=data, timeout=120,
                        headers={"Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                 "x-upsert": "true"})
        if r.status_code >= 400:
            raise RuntimeError(f"Upload failed: HTTP {r.status_code} {r.text[:200]}")

    def cleanup(self, days):
        cutoff = iso(utcnow() - datetime.timedelta(days=days))
        old = self._rest("GET", f"jobs?select=id,file_path&requested_at=lt.{cutoff}").json()
        paths = [o["file_path"] for o in old if o.get("file_path")]
        if paths:
            self.s.delete(f"{self.url}/storage/v1/object/{BUCKET}", json={"prefixes": paths}, timeout=60)
        if old:
            self._rest("DELETE", f"jobs?requested_at=lt.{cutoff}", headers={"Prefer": "return=minimal"})
            log.info(f"Cleanup: removed {len(old)} refreshes older than {days} days")


DB = None


class Reporter:
    """Sends live progress to the website, at most every ~2 seconds."""

    def __init__(self, job_id, labels):
        self.job_id = job_id
        self.progress = {"pct": 2, "branches": {l: {"state": "waiting"} for l in labels}}
        self.message = ""
        self.last = 0.0
        self.lock = threading.Lock()

    def branch(self, label, state, count=None):
        with self.lock:
            b = self.progress["branches"].setdefault(label, {})
            b["state"] = state
            if count is not None:
                b["count"] = count

    def set(self, pct=None, message=None, force=False):
        with self.lock:
            if pct is not None:
                self.progress["pct"] = max(1, min(99, int(pct)))
            if message is not None:
                self.message = message
            if not force and time.monotonic() - self.last < 2:
                return
            self.last = time.monotonic()
            payload = {"progress": json.loads(json.dumps(self.progress)), "message": self.message}
        try:
            DB.update(self.job_id, **payload)
        except Exception as e:
            log.info(f"(progress update skipped: {e})")


# ===========================================================================
# Shared Excel helpers
# ===========================================================================

def to_number(v):
    if isinstance(v, (int, float)):
        return v
    try:
        return float(str(v).replace("QAR", "").strip())
    except (TypeError, ValueError):
        return None


def template_names(path):
    ws = load_workbook(path).active
    return {str(ws.cell(r, 1).value).strip().lower()
            for r in range(2, ws.max_row + 1) if ws.cell(r, 1).value}


def build_table(path, labels, branch_cols, price_col):
    """Reads the finished Excel back into a small table for the website."""
    ws = load_workbook(path).active
    rows = []
    for r in range(2, ws.max_row + 1):
        name = ws.cell(r, 1).value
        if not name:
            continue
        stocks = []
        for c in branch_cols:
            v = ws.cell(r, c).value
            stocks.append(v if isinstance(v, (int, float)) and not isinstance(v, bool) else None)
        rows.append([str(name).strip(), str(ws.cell(r, 2).value or "").strip(),
                     to_number(ws.cell(r, price_col).value), stocks])
    return {"branches": labels, "rows": rows}


# ===========================================================================
# SNOONU
# ===========================================================================

def snoonu_keys(name):
    base = re.sub(r"[^a-z0-9]", "", str(name or "").lower())
    no_brand = re.sub(r"^freshqa", "", base)
    return [base, no_brand] if no_brand and no_brand != base else [base]


def snoonu_products(html):
    m = NEXT_DATA_RE.search(html)
    if not m:
        raise RuntimeError("product data not found on the page (Snoonu may have changed its site)")
    data = json.loads(m.group(1))
    out = []
    for q in data.get("props", {}).get("pageProps", {}).get("dehydratedState", {}).get("queries", []):
        key = q.get("queryKey") or []
        if key and key[0] == "merchant-subcategory-products":
            for sub in (q.get("state", {}).get("data") or {}).get("subCategories", []):
                for item in sub.get("data", []):
                    out.append({"name": item.get("englishName") or item.get("name"),
                                "category": sub.get("name", ""),
                                "price": item.get("price"),
                                "stock": item.get("stockCount")})
    return out


def run_snoonu(job):
    labels = [b["label"] for b in SNOONU_BRANCHES]
    rep = Reporter(job["id"], labels)
    rep.set(3, "Connecting to Snoonu", force=True)
    session = requests.Session()
    session.headers.update(BROWSER_HEADERS)

    results = []
    for i, b in enumerate(SNOONU_BRANCHES):
        rep.branch(b["label"], "running")
        rep.set(5 + i * 85 / len(SNOONU_BRANCHES), f"Checking {b['label']} ({i + 1} of {len(SNOONU_BRANCHES)})", force=True)
        err = None
        for attempt in range(3):
            try:
                r = session.get(b["url"], timeout=30)
                r.raise_for_status()
                products = snoonu_products(r.text)
                break
            except Exception as e:
                err = e
                time.sleep(1.5 * (attempt + 1))
        else:
            results.append({"ok": False, "error": str(err)[:200]})
            rep.branch(b["label"], "failed")
            log.info(f"  Snoonu {b['label']}: FAILED - {err}")
            continue
        results.append({"ok": True, "products": products})
        rep.branch(b["label"], "done", len(products))
        log.info(f"  Snoonu {b['label']}: {len(products)} products")
        if i < len(SNOONU_BRANCHES) - 1:
            time.sleep(SNOONU_DELAY)

    if not any(r["ok"] for r in results):
        raise RuntimeError("Could not read any Snoonu branch. First error: " + results[0]["error"])

    rep.set(93, "Filling your Excel template", force=True)
    wb = load_workbook(SNOONU_TEMPLATE)
    ws = wb.active
    n = len(SNOONU_BRANCHES)

    key_to_row, last_named = {}, 1
    for r in range(2, ws.max_row + 1):
        name = ws.cell(r, 1).value
        if name:
            last_named = r
            for k in snoonu_keys(name):
                key_to_row.setdefault(k, r)
    named_rows = sorted(set(key_to_row.values()))

    # Loaded branch -> start at 0. Failed branch -> EMPTY (unknown, never fake 0).
    for bi, res in enumerate(results):
        col = SNOONU_FIRST_BRANCH_COL + bi
        for r in named_rows:
            ws.cell(r, col).value = 0 if res["ok"] else None

    style_row = ws.max_row if ws.max_row > 1 else last_named
    next_row = ws.max_row + 1
    first_l = get_column_letter(SNOONU_FIRST_BRANCH_COL)
    last_l = get_column_letter(SNOONU_FIRST_BRANCH_COL + n - 1)
    helper_l = get_column_letter(SNOONU_HELPER_COL)
    new_names = []

    for bi, res in enumerate(results):
        if not res["ok"]:
            continue
        col = SNOONU_FIRST_BRANCH_COL + bi
        for p in res["products"]:
            if not p["name"]:
                continue
            keys = snoonu_keys(p["name"])
            row = next((key_to_row[k] for k in keys if k in key_to_row), None)
            if row is None:
                row = next_row
                next_row += 1
                for c in range(1, SNOONU_LAST_COL + 1):
                    ws.cell(row, c)._style = copy.copy(ws.cell(style_row, c)._style)
                ws.cell(row, 1).value = p["name"]
                for bj, other in enumerate(results):
                    ws.cell(row, SNOONU_FIRST_BRANCH_COL + bj).value = 0 if other["ok"] else None
                ws.cell(row, SNOONU_TOTAL_COL).value = f"=SUM({first_l}{row}:{last_l}{row})"
                ws.cell(row, SNOONU_HELPER_COL).value = f"=COUNTIF({first_l}{row}:{last_l}{row}, 0)"
                ws.cell(row, SNOONU_FILL_COL).value = f"={helper_l}{row}/{n}"
                for k in keys:
                    key_to_row[k] = row
                new_names.append(p["name"])
            if ws.cell(row, 2).value in (None, ""):
                ws.cell(row, 2).value = p.get("category")
            if ws.cell(row, 3).value in (None, ""):
                ws.cell(row, 3).value = p.get("price")
            ws.cell(row, col).value = p["stock"] if p["stock"] is not None else 0

    os.makedirs(OUT_DIR, exist_ok=True)
    out = os.path.join(OUT_DIR, f"Snoonu_Stock_{local_stamp()}.xlsx")
    wb.save(out)

    table = build_table(out, labels, [SNOONU_FIRST_BRANCH_COL + i for i in range(n)], price_col=3)
    failed = [labels[i] for i, r in enumerate(results) if not r["ok"]]
    table.update({"incomplete": failed, "new_products": new_names,
                  "branch_errors": {labels[i]: r["error"] for i, r in enumerate(results) if not r["ok"]}})
    ok_count = n - len(failed)
    return out, table, f"{ok_count} of {n} branches, {len(table['rows'])} products"


# ===========================================================================
# TALABAT (uses your talabat.py unchanged - its speed control and safeguards)
# ===========================================================================

_talabat_module = None
_TALABAT_DONE_RE = re.compile(r"done:\s+(.+?)\s+\((\d+)/(\d+) categories\)")
_TALABAT_TICK_RE = re.compile(r"(\d+) pages fetched, (\d+)/(\d+) categories done")


def talabat():
    global _talabat_module
    if _talabat_module is None:
        import talabat as T
        _talabat_module = T
    return _talabat_module


def run_talabat(job):
    T = talabat()
    labels = [b["label"] for b in T.BRANCH_URLS]
    rep = Reporter(job["id"], labels)
    rep.set(2, "Starting a Talabat session", force=True)

    # Fresh counters for this run (the module keeps them between runs otherwise)
    T.RUN_START = time.time()
    T.LIMITER = T.AdaptiveRateLimiter(T.START_RATE, T.MIN_RATE, T.MAX_RATE)
    T._net["count"] = 0
    T.FEED_STATE.update({"on": False, "extra": {}, "broken": False})
    for b in T.BRANCH_URLS:
        b["_prefix"], b["_query"] = T.get_base_parts(b["url"])

    def hooked_print(*args, **kwargs):
        line = " ".join(str(a) for a in args)
        log.info("  talabat| " + line.strip())
        m = _TALABAT_DONE_RE.search(line)
        if m:
            rep.branch(m.group(1).strip(), "done")
            rep.set(8 + int(m.group(2)) / max(1, int(m.group(3))) * 82,
                    f"{m.group(1).strip()} finished", force=True)
            return
        m = _TALABAT_TICK_RE.search(line)
        if m:
            rep.set(8 + int(m.group(2)) / max(1, int(m.group(3))) * 82,
                    f"{m.group(1)} pages read, {m.group(2)} of {m.group(3)} category checks done")
            return
        if "quota reached" in line:
            wait = re.search(r"waiting (\d+)s", line)
            rep.set(message="Talabat asked us to slow down, pausing "
                    + (f"{wait.group(1)} seconds" if wait else "briefly"), force=True)
        elif "slow retry round" in line:
            rep.set(message="Re-checking a few pages that did not load", force=True)

    original_print = T.safe_print
    T.safe_print = hooked_print
    try:
        T.prepare()
        T.load_learned_speed()
        T.load_feed_settings()
        T.warm_up()
        rep.set(5, "Reading Talabat's category list", force=True)
        cat_names, all_keys, _ = T.read_category_tree()
        allow = T.load_allowlist()
        cat_keys = [k for k in all_keys if k in allow]
        mode_key = "fast" + ("-feed" + json.dumps(T.FEED_STATE["extra"], sort_keys=True)
                             if T.FEED_STATE["on"] else "")
        progress = T.load_progress(mode_key)
        for l in labels:
            rep.branch(l, "running")
        rep.set(8, f"Checking {len(cat_keys)} categories in {len(labels)} branches", force=True)

        state, incomplete = T.crawl(T.BRANCH_URLS, cat_keys, cat_names, progress)
        complete = {b["label"]: T.branch_products(state, b["label"], cat_keys)
                    for b in T.BRANCH_URLS if b["label"] not in incomplete}
        T.save_learned_speed()

        if not complete:
            raise RuntimeError("Talabat could not be read for any branch. Try again in a few minutes.")

        rep.set(93, "Filling your Excel template", force=True)
        os.makedirs(OUT_DIR, exist_ok=True)
        out = os.path.join(OUT_DIR, f"Talabat_Stock_{local_stamp()}.xlsx")
        T.OUTPUT_PATH = out
        T.write_results(T.TEMPLATE_PATH, complete, reset_columns=True, blank_labels=incomplete)
        if not incomplete:
            T.clear_progress()
    finally:
        T.safe_print = original_print

    for l in labels:
        if l in complete:
            rep.branch(l, "done", len(complete[l]))
        else:
            rep.branch(l, "failed")
    rep.set(97, "Preparing the results", force=True)

    before = template_names(T.TEMPLATE_PATH)
    table = build_table(out, labels, [b["_col"] for b in T.BRANCH_URLS], price_col=4)
    table.update({"incomplete": list(incomplete),
                  "new_products": [r[0] for r in table["rows"] if r[0].strip().lower() not in before]})
    return out, table, f"{len(complete)} of {len(labels)} branches, {len(table['rows'])} products"


# ===========================================================================
# Workers
# ===========================================================================

RUNNERS = {"snoonu": run_snoonu, "talabat": run_talabat}


def process(job):
    source = job["source"]
    log.info(f"{source}: refresh {job['id']} started")
    t0 = time.time()
    try:
        out, table, summary = RUNNERS[source](job)
        bucket_path = f"{source}/{os.path.basename(out)}"
        for attempt in range(3):
            try:
                DB.upload(bucket_path, out)
                break
            except Exception:
                if attempt == 2:
                    raise
                time.sleep(3)
        final = {"status": "done", "finished_at": iso(), "file_path": bucket_path,
                 "result": table, "message": summary,
                 "progress": {"pct": 100, "branches": {}}}
        for attempt in range(3):
            try:
                DB.update(job["id"], **final)
                break
            except Exception:
                if attempt == 2:
                    raise
                time.sleep(3)
        log.info(f"{source}: done in {time.time() - t0:.0f}s - {summary}")
    except BaseException as e:   # talabat.py uses SystemExit for template problems
        msg = str(e) or e.__class__.__name__
        log.info(f"{source}: FAILED - {msg}\n{traceback.format_exc()}")
        try:
            DB.update(job["id"], status="error", finished_at=iso(), error=msg[:500])
        except Exception as e2:
            log.info(f"(could not report the error: {e2})")
        if isinstance(e, KeyboardInterrupt):
            raise


def worker(source):
    streak = 0
    while True:
        try:
            job = DB.claim(source)
            streak = 0
            if job:
                process(job)
                continue
        except Exception as e:
            streak += 1
            if streak in (1, 10) or streak % 100 == 0:
                log.info(f"{source}: connection problem ({streak}x): {e}")
        time.sleep(POLL_SECONDS if streak < 5 else 30)


def heartbeat_loop():
    last_cleanup = 0.0
    streak = 0
    while True:
        try:
            DB.heartbeat()
            if streak:
                log.info("Connection to Supabase is back")
            streak = 0
            if time.time() - last_cleanup > 12 * 3600:
                last_cleanup = time.time()
                DB.cleanup(KEEP_DAYS)
        except Exception as e:
            streak += 1
            if streak in (1, 10) or streak % 100 == 0:
                log.info(f"Heartbeat problem ({streak}x): {e}")
        time.sleep(HEARTBEAT_SECONDS)


def single_instance():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", 47812))
    except OSError:
        log.info("FreshQA agent is already running - this copy will exit.")
        sys.exit(0)
    return s


def main():
    global DB
    if "PASTE_" in SUPABASE_URL or "PASTE_" in SUPABASE_SERVICE_KEY:
        log.info("Set SUPABASE_URL and SUPABASE_SERVICE_KEY at the top of freshqa_agent.py first.")
        return
    for f in (SNOONU_TEMPLATE, "Talabat_Temp.xlsx", "talabat.py"):
        if not os.path.exists(os.path.join(HERE, f)):
            log.info(f"Missing file next to the agent: {f}")
    _lock = single_instance()
    DB = Supabase(SUPABASE_URL, SUPABASE_SERVICE_KEY)
    try:
        DB.fail_interrupted()
    except Exception as e:
        log.info(f"(could not tidy old refreshes: {e})")
    log.info(f"FreshQA agent {AGENT_VERSION} started - waiting for 'Refresh now'.")

    threads = [threading.Thread(target=heartbeat_loop, name="beat", daemon=True)]
    threads += [threading.Thread(target=worker, args=(s,), name=s, daemon=True) for s in RUNNERS]
    for t in threads:
        t.start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        log.info("Agent stopped.")


if __name__ == "__main__":
    main()
