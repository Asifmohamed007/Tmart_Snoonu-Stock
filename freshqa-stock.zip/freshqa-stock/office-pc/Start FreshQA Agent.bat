@echo off
cd /d "%~dp0"
start "" pythonw freshqa_agent.py
