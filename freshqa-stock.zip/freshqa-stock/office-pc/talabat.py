"""
Talabat Mart - Freshqa Stock -> Template Updater   (v3 - FAST)
------------------------------------------------------------------
Crawls every Talabat branch in BRANCH_URLS and writes Freshqa stock
quantities straight into Talabat_Temp.xlsx, saving the result as
Talabat_Stock_Updated.xlsx.

Template layout (detected automatically from the header row):
    A = Item Name (EN)   B = Category   C = SKU   D = Price
    E .. (column before "Total") = one column per branch
    "Total"         -> =SUM of branch columns          (rewritten every run)
    helper column   -> =COUNTIF(branch columns, 0)     (rewritten every run)
    "Filling Rate"  -> =helper / number of branches    (rewritten every run)
    Anything after that (Overall offer, Pro Deal, ...) is never touched.

WHY THIS VERSION IS FAST
    * All branches are crawled AT THE SAME TIME by a shared worker pool,
      instead of one branch after another.
    * Extra pages of a category are fetched in parallel, not one by one.
    * The category structure is read ONCE, not once per branch.
    * Speed is controlled by ONE shared "requests per second" limiter
      that adapts on its own: it speeds up while Talabat answers
      normally, and the moment Talabat pushes back it slows down, pauses
      briefly, and remembers that speed as its ceiling. So instead of
      hitting the long 4-minute circuit-breaker cut-off, the run settles
      at the fastest pace Talabat accepts.
    * It REMEMBERS that pace (.talabat_speed.json), so the next run starts
      near full speed straight away instead of warming up again.

ACCURACY SAFEGUARDS
    * A page is only accepted if it really contains Talabat's product
      data; challenge/blocked pages are retried, never read as "0 stock".
    * Every category page of every branch must be fetched successfully.
      Failed pages get extra slow retry rounds at the end.
    * If a branch STILL can't be completed, its column is left EMPTY
      (NOT filled with zeros) and the run tells you exactly which branch,
      so the sheet never shows fake out-of-stock numbers. Just run the
      same command again - only the missing pieces are fetched.

ADDING A BRANCH (e.g. the 12th)
    1. In Talabat_Temp.xlsx insert a new column just before "Total" and
       put the branch name in row 1.
    2. Add one line to BRANCH_URLS below with that column letter, and
       update the column letters of any branches that shifted.
    The Total / helper / Filling Rate formulas adjust automatically.
    The script checks the config against the template before crawling
    and stops with a clear message if something doesn't line up.

USAGE
    python talabat_stock.py                 normal fast run
    python talabat_stock.py --fresh         ignore saved partial progress
    python talabat_stock.py --full          crawl EVERY category (slower);
                                            also refreshes the category list
    python talabat_stock.py --backfill-category fruit-veg/best-in-season
    python talabat_stock.py --list-categories fruit-veg
    python talabat_stock.py --diagnostic    print raw item fields of matches
    python talabat_stock.py --inspect       look at one page's structure
    python talabat_stock.py --probe-feed    test Talabat's product API (run once)
    python talabat_stock.py --no-feed       force the old web-page method

Requirements (install once):
    pip install requests openpyxl
"""

import os
import re
import sys
import json
import time
import random
import threading
from collections import deque
import datetime
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED

import requests
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, column_index_from_string

# ---------------------------------------------------------------------------
# CONFIGURE THESE
# ---------------------------------------------------------------------------

TEMPLATE_PATH = "Talabat_Temp.xlsx"
OUTPUT_PATH = "Talabat_Stock_Updated.xlsx"
BRAND_FILTER = "freshqa"

# "column" = the EXACT column letter of this branch in the template.
BRANCH_URLS = [
    {"label": "Wukair",           "column": "E", "url": "https://www.talabat.com/qatar/grocery/613147/daily-by-talabat/ready-to-eat/ready-meals?aid=1758"},
    {"label": "Al Rayyan",        "column": "F", "url": "https://www.talabat.com/qatar/grocery/604314/daily-by-talabat/ready-to-eat/ready-meals?aid=1739"},
    {"label": "Bin Omran",        "column": "G", "url": "https://www.talabat.com/qatar/grocery/600710/daily-by-talabat/ready-to-eat/ready-meals?aid=1753"},
    {"label": "Gharafa",          "column": "H", "url": "https://www.talabat.com/qatar/grocery/780560/daily-by-talabat/ready-to-eat/ready-meals?aid=1650"},
    {"label": "Muntaza",          "column": "I", "url": "https://www.talabat.com/qatar/grocery/619614/daily-by-talabat/ready-to-eat/ready-meals?aid=1653"},
    {"label": "Um Salal Mohamed", "column": "J", "url": "https://www.talabat.com/qatar/grocery/604315/daily-by-talabat/ready-to-eat/ready-meals?aid=1750"},
    {"label": "Um Salal Ali",     "column": "K", "url": "https://www.talabat.com/qatar/grocery/792665/daily-by-talabat/ready-to-eat/ready-meals?aid=5595"},
    {"label": "Lusail",           "column": "L", "url": "https://www.talabat.com/qatar/grocery/610747/daily-by-talabat/ready-to-eat/ready-meals?aid=1684"},
    {"label": "Al khor",          "column": "M", "url": "https://www.talabat.com/qatar/grocery/647093/daily-by-talabat/ready-to-eat/ready-meals?aid=1637"},
    {"label": "Abu Hamour",       "column": "N", "url": "https://www.talabat.com/qatar/grocery/795218/daily-by-talabat/ready-to-eat/ready-meals?aid=1754"},
    {"label": "Thumama",          "column": "O", "url": "https://www.talabat.com/qatar/grocery/795217/daily-by-talabat/ready-to-eat/ready-meals?aid=1627"},
]

# Fixed columns (1 = A)
HEADER_ROW = 1
COL_NAME = 1
COL_CATEGORY = 2
COL_SKU = 3
COL_PRICE = 4
BRANCH_START_COL = 5

# Categories known to contain Freshqa products (shared by all branches).
PRESEEDED_ALLOWLIST = [
    "fruit-veg/fresh-fruit",
    "fruit-veg/best-in-season",
    "ready-to-eat/freshly-squeezed-juices",
    "ready-to-eat/fruit-cuts",
    "ready-to-eat/snacks-desserts",
    "ice-cream/bars-cones-sticks",
    "ready-to-eat/salads",
    "ready-to-eat/starters-sides",
    "dairy-eggs/chilled-desserts",
    "deli/pickles-olives",
    "ready-to-eat/sandwiches-wraps",
    "beverages/juices",
    "milk/fresh-milk",
    "beverages/specialty-drinks",
    "coffee-tea/creamers",
    "cooking-baking/baking-ingredients",
]
SKIP_TOP_LEVEL_SLUGS = {"loved-arabic-brands"}

# ---------------------------------------------------------------------------
# SPEED TUNING
# The real speed knob is REQUESTS PER SECOND (shared by all workers), not
# the number of workers. Workers just make sure the limiter is never idle
# while pages are downloading.
# ---------------------------------------------------------------------------

WORKERS = 20              # parallel downloads in flight
START_RATE = 4.5          # requests/second
MAX_RATE = 5.0            # Early push-backs at every speed (12 down to 3.5) turned out
                          # to be the missing-cookie problem, not speed (08-Oct-2026).
                          # Each push-back costs a 60s penalty (= ~200 requests' worth
                          # of time), so a steady safe pace beats a faster risky one.
MIN_RATE = 0.5            # never go slower than this
RAMP_FACTOR = 1.15        # speed x1.15 after every SUCCESSES_PER_STEP clean responses
SUCCESSES_PER_STEP = 6
CEILING_RECOVERY = 80     # clean responses in a row before the ceiling is raised again
LONG_PENALTY = 30         # a Retry-After this long means 'real limit hit': stop probing higher
BLOCK_PAUSE = 6           # seconds everyone waits after Talabat pushes back
                          # (longer if Talabat asks for longer via Retry-After)
MAX_ATTEMPTS = 8          # attempts per page within one round
EXTRA_RETRY_ROUNDS = 3    # slow rounds at the end for anything that failed
RETRY_ROUND_COOLDOWN = 15
REQUEST_TIMEOUT = 30
PROGRESS_MAX_AGE_HOURS = 6   # older saved progress is ignored (stale stock)

PROGRESS_FILE = ".talabat_progress_v3.json"
ALLOWLIST_FILE = ".talabat_relevant_subcategories.json"
SPEED_FILE = ".talabat_speed_v5.json"   # remembers the speed that worked last time
FEED_FILE = ".talabat_feed.json"         # feed API settings confirmed by --probe-feed

# Talabat's product API (found 08-Oct-2026). Same items as the web page but
# as light JSON. Used only after `--probe-feed` has confirmed it works.
FEED_URL = "https://www.talabat.com/nextApi/groceries/stores/{branch_id}/feed"
FEED_COUNTRY_ID = 6     # Qatar

# ---------------------------------------------------------------------------
# COMMAND LINE
# ---------------------------------------------------------------------------

def _arg_value(flag):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1].strip("/")
    return None

FRESH_START = "--fresh" in sys.argv
FORCE_FULL = "--full" in sys.argv or "--discover" in sys.argv
DIAGNOSTIC_MODE = "--diagnostic" in sys.argv
BACKFILL_CATEGORY = _arg_value("--backfill-category")
LIST_CATEGORY = _arg_value("--list-categories")
INSPECT_MODE = "--inspect" in sys.argv
PROBE_FEED_MODE = "--probe-feed" in sys.argv
NO_FEED = "--no-feed" in sys.argv

# ---------------------------------------------------------------------------
# HTTP + ADAPTIVE RATE LIMITER
# ---------------------------------------------------------------------------

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}
NEXT_DATA_RE = re.compile(
    r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>',
    re.DOTALL,
)

_thread_local = threading.local()
RUN_START = time.time()


def fmt_dur(sec):
    sec = int(round(sec))
    m, s_ = divmod(sec, 60)
    return f"{m} min {s_:02d} s" if m else f"{s_} s"


def clock():
    m, s_ = divmod(int(time.time() - RUN_START), 60)
    return f"{m:02d}:{s_:02d}"
_print_lock = threading.Lock()


def safe_print(*args, **kwargs):
    with _print_lock:
        print(*args, **kwargs, flush=True)


_shared_session = None
_session_lock = threading.Lock()


def get_session():
    """ONE session shared by all workers, so they all carry the same Talabat
    cookies - like a single browser. (Separate sessions per worker looked
    like 20 brand-new visitors at once, which Talabat blocked at the start
    of every run.)"""
    global _shared_session
    if _shared_session is None:
        with _session_lock:
            if _shared_session is None:
                s = requests.Session()
                s.headers.update(HEADERS)
                adapter = requests.adapters.HTTPAdapter(pool_connections=4,
                                                        pool_maxsize=WORKERS + 4)
                s.mount("https://", adapter)
                s.mount("http://", adapter)
                _shared_session = s
    return _shared_session


def warm_up():
    """Visit the store page once, slowly, so Talabat sets its cookies before
    the workers start."""
    s = get_session()
    for b in BRANCH_URLS[:2]:
        try:
            s.get(b["url"], timeout=REQUEST_TIMEOUT)
        except requests.RequestException:
            pass
        time.sleep(1.5)
    names = sorted(c.name for c in s.cookies)
    safe_print(f"Session ready ({len(names)} cookies"
               + (f": {', '.join(names[:6])}" if names else "") + ")")


def http_get(url):
    """Single place where the network is touched (easy to test/replace)."""
    return get_session().get(url, timeout=REQUEST_TIMEOUT)


class AdaptiveRateLimiter:
    """
    One shared pace for ALL workers. Spaces requests evenly at `rate`
    per second (with a little jitter), creeps the rate up while responses
    are clean, and on any push-back (429/403/503/soft-404/challenge page)
    halves the rate, pauses everyone briefly and lowers its ceiling so it
    doesn't keep bumping into the same wall.
    """

    def __init__(self, start, lo, hi):
        self.rate = start
        self.lo = lo
        self.hi = hi
        self.lock = threading.Lock()
        self.next_slot = time.monotonic()
        self.paused_until = 0.0
        self.ok_streak = 0
        self.clean_run = 0
        self.last_block = -1e9
        self.best_clean_rate = 0.0
        self.locked = False   # True = never probe above the ceiling again
        self.budget60 = None  # max requests per 60s (learned from push-backs)
        self.pause_ended = -1e9
        self.sent = deque()          # timestamps of recent requests
        self.blocks = 0
        self.quota_waits = 0
        self.requests = 0

    def acquire(self):
        with self.lock:
            now = time.monotonic()
            slot = max(now, self.next_slot, self.paused_until)
            if self.budget60 and len(self.sent) >= self.budget60:
                # Per-minute budget: wait until the oldest request inside the
                # last 60s window has aged out.
                slot = max(slot, self.sent[-self.budget60] + 60.0)
            self.next_slot = slot + (1.0 / self.rate) * random.uniform(0.9, 1.1)
            self.requests += 1
            self.sent.append(slot)
            while self.sent and self.sent[0] < now - 60:
                self.sent.popleft()
        delay = slot - time.monotonic()
        if delay > 0:
            time.sleep(delay)

    def success(self):
        with self.lock:
            self.ok_streak += 1
            self.clean_run += 1
            if self.clean_run >= 30:
                # Only a pace held for a while with zero push-back counts as safe.
                self.best_clean_rate = max(self.best_clean_rate, min(self.rate, self.hi))
            if (self.clean_run >= CEILING_RECOVERY and self.hi < MAX_RATE
                    and not self.locked):
                # A one-off hiccup shouldn't cap the speed forever.
                self.hi = min(MAX_RATE, self.hi * 1.05)
                self.clean_run = 0
            if self.ok_streak >= SUCCESSES_PER_STEP and self.rate < self.hi:
                self.rate = min(self.hi, self.rate * RAMP_FACTOR)
                self.ok_streak = 0

    def blocked(self, retry_after=None, reason=""):
        with self.lock:
            now = time.monotonic()
            self.ok_streak = 0
            self.clean_run = 0
            if now < self.paused_until:
                # Already reacting to this wave of push-back (other requests
                # that were in flight) - don't punish twice.
                return
            self.blocks += 1
            old = self.rate
            if retry_after and retry_after >= LONG_PENALTY:
                # Talabat's QUOTA (about 100-120 pages/minute on average):
                # it lets a burst through, then asks for a ~60s wait. Slowing
                # down doesn't avoid it - it only makes each burst smaller
                # (a 9-minute run proved that) - so wait exactly as long as
                # asked and carry on at the same speed.
                self.quota_waits += 1
                pause = retry_after + 1
                kind = "quota reached"
            else:
                # Short hiccup / error page -> small slow-down, short pause.
                repeated = (now - self.last_block) < 45
                if repeated:
                    self.rate = max(self.lo, old * 0.8)
                pause = max(BLOCK_PAUSE / 3, retry_after or 0)
                kind = "pushed back"
            self.last_block = now
            self.paused_until = now + pause
            self.next_slot = self.paused_until
        safe_print(f"    [{clock()}] Talabat {kind} ({reason or 'no product data'}, "
                   f"request #{self.requests}) - waiting {pause:.0f}s"
                   + (f", speed {old:.2f} -> {self.rate:.2f} req/s" if self.rate != old else ""))

    def reset_for_retry_round(self):
        with self.lock:
            self.rate = max(self.lo, min(self.rate, 1.0))
            self.ok_streak = 0


LIMITER = AdaptiveRateLimiter(START_RATE, MIN_RATE, MAX_RATE)


def load_learned_speed():
    """Start this run at the pace that worked last time (minus a small
    safety margin) instead of re-learning it from scratch."""
    try:
        with open(SPEED_FILE, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return
    rate = float(d.get("safe_rate") or 0)
    ceiling = d.get("ceiling")
    if d.get("budget_per_min"):
        LIMITER.budget60 = int(d["budget_per_min"])
    with LIMITER.lock:
        if rate > 0:
            LIMITER.rate = min(MAX_RATE, max(MIN_RATE, rate * 0.95))
        if ceiling:
            # allow a little probing above last time's limit
            LIMITER.hi = min(MAX_RATE, max(LIMITER.rate, float(ceiling)))
            LIMITER.locked = True   # known limit: go straight to it, don't probe


def _old_speed_file():
    try:
        with open(SPEED_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_learned_speed():
    safe = LIMITER.best_clean_rate
    if LIMITER.blocks:
        safe = min(safe, LIMITER.hi) if safe else LIMITER.hi * 0.9
    if not safe:
        return
    old = _old_speed_file()
    try:
        with open(SPEED_FILE, "w", encoding="utf-8") as f:
            json.dump({"safe_rate": round(safe, 2),
                       "ceiling": (round(LIMITER.hi, 2) if LIMITER.blocks
                                   else old.get("ceiling")),
                       "budget_per_min": LIMITER.budget60 or old.get("budget_per_min"),
                       "updated": datetime.datetime.now().isoformat()}, f, indent=2)
    except Exception:
        pass


_net = {"count": 0, "last_print": 0.0, "lock": threading.Lock()}


def note_network_problem(e):
    with _net["lock"]:
        _net["count"] += 1
        now = time.monotonic()
        if now - _net["last_print"] < 10:
            return
        _net["last_print"] = now
        n = _net["count"]
    kind = "timed out" if isinstance(e, requests.Timeout) else f"failed ({e.__class__.__name__})"
    safe_print(f"    [{clock()}] Talabat didn't answer - request {kind}; retrying "
               f"automatically ({n} so far this run)")


class FetchError(Exception):
    pass


def _retry_after(resp):
    val = resp.headers.get("Retry-After")
    try:
        return float(val) if val else None
    except ValueError:
        return None


def _parse_html(resp):
    m = NEXT_DATA_RE.search(resp.text)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except ValueError:
        return None


def _parse_json(resp):
    try:
        d = resp.json()
    except ValueError:
        return None
    return d if isinstance(d, (dict, list)) else None


def fetch_next_data(url, parser=_parse_html):
    last_err = None
    for attempt in range(1, MAX_ATTEMPTS + 1):
        LIMITER.acquire()
        try:
            resp = http_get(url)
        except requests.RequestException as e:
            last_err = f"network: {e.__class__.__name__}"
            note_network_problem(e)
            time.sleep(min(20, 2 * attempt) + random.uniform(0, 1))
            continue

        code = resp.status_code
        if code == 200:
            data = parser(resp)
            if data is not None:
                LIMITER.success()
                return data
            # 200 but no product data = challenge/interstitial page.
            last_err = "challenge page (no product data)"
            LIMITER.blocked()
            continue

        if code in (429, 403, 503, 404):
            # 404 on a known-good category URL is Talabat's soft block.
            last_err = f"HTTP {code}"
            LIMITER.blocked(_retry_after(resp), reason=f"HTTP {code}")
            continue

        last_err = f"HTTP {code}"
        time.sleep(min(20, 2 * attempt))
    raise FetchError(last_err or "unknown error")


def get_base_parts(branch_url):
    m = re.match(r"(https?://[^?]+?)/[^/?]+/[^/?]+(\?.*)?$", branch_url)
    if not m:
        raise SystemExit(f"Could not understand branch URL: {branch_url}")
    return m.group(1), (m.group(2) or "")


def page_url(prefix, query, cat_key, page):
    url = f"{prefix}/{cat_key}{query}"
    if page > 1:
        url += ("&" if query else "?") + f"page={page}"
    return url


# ---------------------------------------------------------------------------
# CATEGORY STRUCTURE (read once)
# ---------------------------------------------------------------------------

def read_category_tree():
    """Returns ({cat_key: name for Category column}, all_cat_keys, raw tree)."""
    last = None
    for b in BRANCH_URLS:
        try:
            data = fetch_next_data(b["url"])
            cats = data["props"]["pageProps"]["initialState"]["categories"]
            break
        except (FetchError, KeyError, TypeError) as e:
            last = e
            continue
    else:
        raise FetchError(f"could not read Talabat's category list ({last})")

    names, keys = {}, []
    for main in cats:
        if main.get("slug") in SKIP_TOP_LEVEL_SLUGS:
            continue
        subs = main.get("subCategories") or []
        if not subs:
            names[main["slug"]] = main.get("name", main["slug"])
            keys.append(main["slug"])
        for sub in subs:
            k = f"{main['slug']}/{sub['slug']}"
            names[k] = main.get("name", main["slug"])  # same as before: top-level name
            keys.append(k)
    return names, keys, cats


def load_allowlist():
    keys = set(PRESEEDED_ALLOWLIST)
    if os.path.exists(ALLOWLIST_FILE):
        try:
            with open(ALLOWLIST_FILE, encoding="utf-8") as f:
                keys |= set(json.load(f).get("keys", []))
        except Exception:
            pass
    return keys


def save_allowlist(keys):
    try:
        with open(ALLOWLIST_FILE, "w", encoding="utf-8") as f:
            json.dump({"keys": sorted(keys),
                       "updated": datetime.datetime.now().isoformat()}, f, indent=2)
    except Exception as e:
        safe_print(f"(warning: could not save category list: {e})")


# ---------------------------------------------------------------------------
# CRAWLING (all branches in parallel, one shared pace)
# ---------------------------------------------------------------------------

SKU_KEYS = ("sku", "barcode", "productSku", "skuId", "sku_id")


def is_brand_match(item):
    hay = " ".join(str(item.get(k, "")) for k in ("title", "slug", "description")).lower()
    return BRAND_FILTER.lower() in hay


def extract_match(item, category_name):
    skus = [str(item[k]).strip() for k in SKU_KEYS if item.get(k) not in (None, "")]
    return {
        "Product Name": item.get("title"),
        "Subcategory": category_name,
        "Price (QAR)": item.get("price"),
        "Stock Amount": item.get("stockAmount"),
        "SKUs": skus,
    }


_diag_printed = set()


def branch_id_of(branch):
    m = re.search(r"/grocery/(\d+)/", branch["url"])
    return m.group(1) if m else None


def feed_url(branch, cat_key, page, extra=None):
    parts = cat_key.split("/", 1)
    params = [f"countryId={FEED_COUNTRY_ID}", f"categorySlug={parts[0]}"]
    if len(parts) > 1:
        params.append(f"subCategorySlug={parts[1]}")
    params.append(f"page={page}")
    for k, v in (extra or {}).items():
        params.append(f"{k}={v}")
    return FEED_URL.format(branch_id=branch_id_of(branch)) + "?" + "&".join(params)


_PAGECOUNT_KEYS = ("pageCount", "totalPages", "pagesCount", "lastPage", "pages")


def find_items_payload(data):
    """Locate (items, pageCount) in either the web page data or the feed JSON.
    Returns (None, None) if the structure isn't recognised."""
    if isinstance(data, dict):
        st = data.get("props", {}).get("pageProps", {}).get("initialState", {})
        if isinstance(st, dict) and isinstance(st.get("itemsData"), dict):
            d = st["itemsData"]
            return d.get("items") or [], d.get("pageCount")
    # Product API shape (08-Oct-2026):
    #   {"categories": [...], "itemGroups": [{"title": ..., "items": [...]}], "pageCount": 8}
    if isinstance(data, dict) and isinstance(data.get("itemGroups"), list):
        items, seen = [], set()
        for grp in data["itemGroups"]:
            for it in (grp or {}).get("items") or []:
                key = it.get("id") or it.get("sku") or it.get("title")
                if key not in seen:
                    seen.add(key)
                    items.append(it)
        pc = next((data[k] for k in _PAGECOUNT_KEYS if isinstance(data.get(k), int)), None)
        return items, pc
    found = []

    def walk(o, depth):
        if depth > 6 or found:
            return
        if isinstance(o, dict):
            its = o.get("items")
            if isinstance(its, list) and (not its or (isinstance(its[0], dict)
                                                      and "stockAmount" in its[0])):
                pc = next((o[k] for k in _PAGECOUNT_KEYS if isinstance(o.get(k), int)), None)
                found.append((its, pc))
                return
            for v in o.values():
                walk(v, depth + 1)

    walk(data, 0)
    return found[0] if found else (None, None)


FEED_STATE = {"on": False, "extra": {}, "broken": False}


def load_feed_settings():
    if NO_FEED:
        return
    try:
        with open(FEED_FILE, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return
    if d.get("works"):
        FEED_STATE["on"] = True
        FEED_STATE["extra"] = d.get("extra") or {}


def fetch_page(branch, cat_key, page, cat_names):
    items = None
    if FEED_STATE["on"] and not FEED_STATE["broken"]:
        data = fetch_next_data(feed_url(branch, cat_key, page, FEED_STATE["extra"]),
                               parser=_parse_json)
        items, page_count = find_items_payload(data)
        if items is None or page_count is None:
            # Talabat changed the API - switch everything back to web pages.
            if not FEED_STATE["broken"]:
                FEED_STATE["broken"] = True
                safe_print("  ! Product API answered in an unexpected format - "
                           "switching to the web-page method for this run.")
            items = None
    if items is None:
        data = fetch_next_data(page_url(branch["_prefix"], branch["_query"], cat_key, page))
        items, page_count = find_items_payload(data)
        if items is None:
            # A real category page always has itemsData. Treat as a bad page.
            LIMITER.blocked()
            raise FetchError("page had no item list")
    page_count = max(1, int(page_count or 1))
    name = cat_names.get(cat_key, cat_key.split("/")[0])
    matches = [extract_match(it, name) for it in items if is_brand_match(it)]
    if DIAGNOSTIC_MODE:
        for it in items:
            if is_brand_match(it) and cat_key not in _diag_printed:
                _diag_printed.add(cat_key)
                safe_print(f"  [diagnostic] {cat_key}: fields = {sorted(it.keys())}")
    return matches, page_count, len(items)


class CrawlState:
    """Tracks every (branch, category) job and its pages."""

    def __init__(self):
        self.jobs = {}  # (label, cat) -> {"count": int|None, "pages": {n: matches}}

    def job(self, label, cat):
        return self.jobs.setdefault((label, cat), {"count": None, "pages": {}})

    def is_complete(self, label, cat):
        j = self.jobs.get((label, cat))
        return bool(j and j["count"] and len(j["pages"]) >= j["count"])

    def missing_pages(self, label, cat):
        j = self.job(label, cat)
        if j["count"] is None:
            return [1]
        return [p for p in range(1, j["count"] + 1) if p not in j["pages"]]


def run_round(tasks, state, branches_by_label, cat_names, on_job_done):
    """Fetch the given (label, cat, page) tasks; extra pages are queued as
    soon as page 1 tells us how many there are. Returns failed tasks."""
    failed = []
    ex = ThreadPoolExecutor(max_workers=WORKERS)
    meta = {}

    def submit(label, cat, page):
        fut = ex.submit(fetch_page, branches_by_label[label], cat, page, cat_names)
        meta[fut] = (label, cat, page)

    try:
        for t in tasks:
            submit(*t)
        while meta:
            done, _ = wait(list(meta), return_when=FIRST_COMPLETED)
            for fut in done:
                label, cat, page = meta.pop(fut)
                try:
                    matches, count, _n = fut.result()
                except Exception as e:
                    failed.append((label, cat, page))
                    safe_print(f"  ! {label} / {cat} page {page}: {e} (will retry)")
                    continue
                j = state.job(label, cat)
                j["pages"][page] = matches
                if j["count"] is None:
                    j["count"] = count
                    for p in range(2, count + 1):
                        if p not in j["pages"]:
                            submit(label, cat, p)
                if state.is_complete(label, cat):
                    on_job_done(label, cat)
    finally:
        ex.shutdown(wait=True, cancel_futures=True)
    return failed


def crawl(branches, cat_keys, cat_names, progress):
    """Crawl every branch x category. Returns (state, incomplete_branches)."""
    by_label = {b["label"]: b for b in branches}
    state = CrawlState()

    # Restore finished jobs from a previous interrupted run.
    for key, matches in progress.get("done", {}).items():
        label, cat = key.split("|", 1)
        if label in by_label and cat in cat_keys:
            state.jobs[(label, cat)] = {"count": 1, "pages": {1: matches}}

    total_jobs = len(branches) * len(cat_keys)
    done_counter = [sum(1 for k in state.jobs if state.is_complete(*k))]
    if done_counter[0]:
        safe_print(f"Resuming: {done_counter[0]}/{total_jobs} branch-categories "
                   f"already fetched in the last run.")
    branch_left = {b["label"]: sum(1 for c in cat_keys if not state.is_complete(b["label"], c))
                   for b in branches}
    last_save = [time.monotonic()]

    def on_job_done(label, cat):
        j = state.jobs[(label, cat)]
        merged = [m for p in sorted(j["pages"]) for m in j["pages"][p]]
        progress.setdefault("done", {})[f"{label}|{cat}"] = merged
        done_counter[0] += 1
        branch_left[label] -= 1
        if branch_left[label] == 0:
            safe_print(f"  [{clock()}] done: {label:<18} "
                       f"({done_counter[0]}/{total_jobs} categories)")
        if time.monotonic() - last_save[0] > 10:
            save_progress(progress)
            last_save[0] = time.monotonic()

    tasks = [(b["label"], c, p) for b in branches for c in cat_keys
             if not state.is_complete(b["label"], c)
             for p in state.missing_pages(b["label"], c)]
    random.shuffle(tasks)  # spread load across branches
    safe_print(f"Fetching {len(tasks)} category pages across {len(branches)} branches "
               f"({WORKERS} workers, adaptive {MIN_RATE}-{MAX_RATE} req/s)...\n")

    stop_ticker = threading.Event()

    def ticker():
        while not stop_ticker.wait(15):
            try:
                pages = sum(len(j["pages"]) for j in list(state.jobs.values()))
            except Exception:
                continue  # data changed mid-count; try again in 15s
            wait_left = LIMITER.paused_until - time.monotonic()
            extra = (f" | waiting for Talabat, resuming in {wait_left:.0f}s"
                     if wait_left > 1 else f" | {LIMITER.rate:.1f} req/s")
            try:
                safe_print(f"  [{clock()}] {pages} pages fetched, "
                           f"{done_counter[0]}/{total_jobs} categories done{extra}")
            except Exception:
                pass

    threading.Thread(target=ticker, daemon=True).start()
    try:
        failed = run_round(tasks, state, by_label, cat_names, on_job_done)
    finally:
        stop_ticker.set()

    for rnd in range(1, EXTRA_RETRY_ROUNDS + 1):
        failed = sorted({(l, c, p) for l, c, _ in failed
                         for p in state.missing_pages(l, c)})
        if not failed:
            break
        safe_print(f"\n{len(failed)} pages still missing - slow retry round "
                   f"{rnd}/{EXTRA_RETRY_ROUNDS} after {RETRY_ROUND_COOLDOWN}s...")
        save_progress(progress)
        time.sleep(RETRY_ROUND_COOLDOWN)
        LIMITER.reset_for_retry_round()
        failed = run_round(failed, state, by_label, cat_names, on_job_done)

    save_progress(progress)
    incomplete = sorted({b["label"] for b in branches for c in cat_keys
                         if not state.is_complete(b["label"], c)})
    return state, incomplete


def branch_products(state, label, cat_keys):
    """All matched products for one branch, de-duplicated by name."""
    seen, out = set(), []
    for cat in cat_keys:
        j = state.jobs.get((label, cat))
        if not j:
            continue
        for p in sorted(j["pages"]):
            for m in j["pages"][p]:
                key = (m.get("Product Name") or "").strip().lower()
                if key and key not in seen:
                    seen.add(key)
                    out.append(m)
    return out


# ---------------------------------------------------------------------------
# PROGRESS
# ---------------------------------------------------------------------------

def _new_progress(mode_key):
    return {"mode": mode_key, "started": time.time(), "done": {}}


def load_progress(mode_key):
    if FRESH_START or not os.path.exists(PROGRESS_FILE):
        return _new_progress(mode_key)
    try:
        with open(PROGRESS_FILE, encoding="utf-8") as f:
            p = json.load(f)
        age_h = (time.time() - p.get("started", 0)) / 3600
        if p.get("mode") != mode_key or age_h > PROGRESS_MAX_AGE_HOURS:
            return _new_progress(mode_key)
        return p
    except Exception:
        return _new_progress(mode_key)


def save_progress(progress):
    tmp = f"{PROGRESS_FILE}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(progress, f)
        os.replace(tmp, PROGRESS_FILE)
    except Exception as e:
        safe_print(f"(warning: could not save progress: {e})")


def clear_progress():
    try:
        os.remove(PROGRESS_FILE)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# TEMPLATE LAYOUT + VALIDATION
# ---------------------------------------------------------------------------

def detect_layout(ws):
    headers = {c: str(ws.cell(HEADER_ROW, c).value or "").strip().lower()
               for c in range(1, ws.max_column + 1)}
    total = next((c for c, h in headers.items() if h == "total"), None)
    fill = next((c for c, h in headers.items() if h.startswith("filling")), None)
    if not total:
        raise SystemExit('Template problem: no "Total" header found in row 1.')
    if not fill or fill <= total:
        raise SystemExit('Template problem: "Filling Rate" header must come after "Total".')
    branch_cols = list(range(BRANCH_START_COL, total))
    helper = total + 1 if total + 1 < fill else None
    return {"total": total, "helper": helper, "fill": fill,
            "branch_cols": branch_cols, "headers": headers}


def validate_config(layout):
    cols = []
    for b in BRANCH_URLS:
        try:
            c = column_index_from_string(b["column"].strip().upper())
        except ValueError:
            raise SystemExit(f'Config problem: "{b["column"]}" for {b["label"]} '
                             f'is not a column letter.')
        if c not in layout["branch_cols"]:
            first = get_column_letter(layout["branch_cols"][0])
            last = get_column_letter(layout["branch_cols"][-1])
            raise SystemExit(
                f'Config problem: {b["label"]} is set to column {b["column"]}, but the '
                f'template branch columns are {first}-{last} (before "Total").\n'
                f'If you added a branch, insert its column before "Total" in the template.')
        cols.append(c)
        b["_col"] = c
    dupes = {get_column_letter(c) for c in cols if cols.count(c) > 1}
    if dupes:
        raise SystemExit(f"Config problem: two branches share column(s) "
                         f"{', '.join(sorted(dupes))}.")
    for c in layout["branch_cols"]:
        if c not in cols:
            safe_print(f'Note: template column {get_column_letter(c)} '
                       f'("{layout["headers"][c]}") has no branch URL - left as is.')


# ---------------------------------------------------------------------------
# MATCHING + WRITING
# ---------------------------------------------------------------------------

_SIZE_RE = re.compile(r'(\d+(?:\.\d+)?)\s*(ml|l|kg|gm|grams?|g|pcs|pieces?)\b')
_UNIT_MAP = {"ml": "ml", "l": "l", "kg": "kg", "g": "g", "gm": "g", "gram": "g",
             "grams": "g", "pcs": "pcs", "piece": "pcs", "pieces": "pcs"}
_STOPWORDS = {"freshqa", "fresh", "premium", "the", "with", "and", "of", "a", "an"}
_UNIT_WORDS = set(_UNIT_MAP)
_SIZE_TOKEN_RE = re.compile(r'^\d+(\.\d+)?(ml|l|kg|g|gm|grams?|pcs|pieces?)$')
_PUNCT_RE = re.compile(r'[.,()\-\u00a0]')


def normalize_name(name):
    return (name or "").strip().lower()


def normalize_sku(v):
    if v is None:
        return ""
    s = str(v).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s


def extract_size_key(name):
    if not name:
        return None
    m = _SIZE_RE.search(name.lower().replace(",", " "))
    if not m:
        return None
    qty, unit = m.groups()
    if "." in qty:
        qty = qty.rstrip("0").rstrip(".")
    return f"{qty}{_UNIT_MAP.get(unit, unit)}"


def tokenize_for_fuzzy(name):
    if not name:
        return set()
    words = set()
    for w in _PUNCT_RE.sub(" ", name.lower()).split():
        if (not w or w in _STOPWORDS or w in _UNIT_WORDS or w.isdigit()
                or _SIZE_TOKEN_RE.match(w)):
            continue
        if len(w) > 4 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]
        words.add(w)
    return words


class RowIndex:
    def __init__(self, ws):
        self.ws = ws
        self.by_name, self.by_sku, self.tokens, self.size = {}, {}, {}, {}
        last = HEADER_ROW
        for r in range(HEADER_ROW + 1, ws.max_row + 1):
            name = ws.cell(r, COL_NAME).value
            if not name:
                continue
            last = r
            self._register(r, str(name), ws.cell(r, COL_SKU).value)
        self.next_row = last + 1

    def _register(self, r, name, sku):
        self.by_name.setdefault(normalize_name(name), r)
        s = normalize_sku(sku)
        if s:
            self.by_sku.setdefault(s, r)
        self.tokens[r] = tokenize_for_fuzzy(name)
        self.size[r] = extract_size_key(name)

    def data_rows(self):
        return sorted(self.tokens)

    def find(self, product, claimed):
        for s in product.get("SKUs") or []:
            r = self.by_sku.get(normalize_sku(s))
            if r:
                return r, "sku"
        name = product.get("Product Name") or ""
        r = self.by_name.get(normalize_name(name))
        if r:
            return r, "exact"
        inc_size, inc_tok = extract_size_key(name), tokenize_for_fuzzy(name)
        if not inc_tok:
            return None, None
        best, best_score = None, 0.0
        threshold = 0.55 if inc_size else 0.7
        for row, tok in self.tokens.items():
            if row in claimed:  # already filled by another product in this branch
                continue
            sz = self.size.get(row)
            if inc_size and sz and inc_size != sz:
                continue
            union = inc_tok | tok
            if not union:
                continue
            score = len(inc_tok & tok) / len(union)
            if score >= threshold and score > best_score:
                best, best_score = row, score
        return (best, "fuzzy") if best else (None, None)

    def add_row(self, product, layout):
        r = self.next_row
        self.next_row += 1
        ws = self.ws
        ws.cell(r, COL_NAME).value = product.get("Product Name")
        if product.get("SKUs"):
            ws.cell(r, COL_SKU).value = product["SKUs"][0]
        for c in layout["branch_cols"]:
            ws.cell(r, c).value = 0
        self._register(r, product.get("Product Name") or "", ws.cell(r, COL_SKU).value)
        return r


def set_row_formulas(ws, row, layout):
    cols = layout["branch_cols"]
    a, b = get_column_letter(cols[0]), get_column_letter(cols[-1])
    ws.cell(row, layout["total"]).value = f"=SUM({a}{row}:{b}{row})"
    if layout["helper"]:
        h = layout["helper"]
        ws.cell(row, h).value = f"=COUNTIF({a}{row}:{b}{row}, 0)"
        ws.cell(row, layout["fill"]).value = f"={get_column_letter(h)}{row}/{len(cols)}"


def write_results(source_path, results, reset_columns, blank_labels=()):
    """
    results: {branch_label: [products]} - only branches whose data is COMPLETE.
    reset_columns: zero those branches' columns first, so anything not on
    Talabat today correctly shows 0.
    """
    wb = load_workbook(source_path)
    ws = wb.active
    layout = detect_layout(ws)
    idx = RowIndex(ws)
    fuzzy_log, added_total, cells = [], 0, 0

    for b in BRANCH_URLS:
        if b["label"] not in results:
            continue
        col = b["_col"]
        if reset_columns:
            for r in idx.data_rows():
                ws.cell(r, col).value = 0
        claimed = {}
        for p in results[b["label"]]:
            row, how = idx.find(p, claimed)
            if row is None:
                row = idx.add_row(p, layout)
                added_total += 1
            if row in claimed:
                # Same row hit twice in one branch - keep the first, never double count.
                continue
            if how == "fuzzy":
                fuzzy_log.append((p["Product Name"], ws.cell(row, COL_NAME).value))
            claimed[row] = p["Product Name"]
            ws.cell(row, col).value = p.get("Stock Amount") or 0
            cells += 1
            if ws.cell(row, COL_CATEGORY).value in (None, ""):
                ws.cell(row, COL_CATEGORY).value = p.get("Subcategory")
            if ws.cell(row, COL_PRICE).value in (None, ""):
                ws.cell(row, COL_PRICE).value = p.get("Price (QAR)")

    blank_cols = {b["_col"] for b in BRANCH_URLS if b["label"] in blank_labels}
    for r in idx.data_rows():
        for c in layout["branch_cols"]:
            if c in blank_cols:
                ws.cell(r, c).value = None   # unknown, NOT zero
            elif ws.cell(r, c).value in (None, ""):
                ws.cell(r, c).value = 0
        set_row_formulas(ws, r, layout)

    tmp = OUTPUT_PATH + ".tmp.xlsx"
    wb.save(tmp)
    while True:
        try:
            os.replace(tmp, OUTPUT_PATH)
            break
        except PermissionError:
            safe_print(f"\n{OUTPUT_PATH} is open in Excel - close it, then press "
                       f"Enter to save (nothing needs to be fetched again).")
            try:
                input()
            except EOFError:
                raise SystemExit("Could not save - close Excel and run again.")
    return cells, added_total, fuzzy_log


def print_fuzzy(fuzzy_log):
    if not fuzzy_log:
        return
    pairs = sorted(set(fuzzy_log))
    safe_print(f"\n{len(pairs)} products matched by similar wording (not exact "
               f"name/SKU) - worth a quick glance:")
    for t, n in pairs:
        safe_print(f'  Talabat: "{t}"\n     ->   template row: "{n}"')


# ---------------------------------------------------------------------------
# MODES
# ---------------------------------------------------------------------------

def output_is_locked():
    if not os.path.exists(OUTPUT_PATH):
        return False
    try:
        with open(OUTPUT_PATH, "a+b"):
            return False
    except PermissionError:
        return True


def prepare():
    if not os.path.exists(TEMPLATE_PATH):
        raise SystemExit(f"Template file not found: {TEMPLATE_PATH}")
    if output_is_locked():
        safe_print(f"Note: {OUTPUT_PATH} is open in Excel - close it before the run "
                   f"finishes (you'll be asked again at the end if it's still open).")
    layout = detect_layout(load_workbook(TEMPLATE_PATH).active)
    validate_config(layout)
    return layout


def run_normal():
    prepare()
    load_learned_speed()
    load_feed_settings()
    safe_print("Method: " + ("Talabat product API" + (f" {FEED_STATE['extra']}" if FEED_STATE["extra"] else "")
                             if FEED_STATE["on"] else "web pages (run --probe-feed once to try the faster API)"))
    start = RUN_START
    safe_print(f"Started at {time.strftime('%H:%M:%S')}")
    safe_print(f"Starting speed: {LIMITER.rate:.1f} req/s"
               + (f", max {LIMITER.budget60} requests/minute" if LIMITER.budget60 else ""))
    warm_up()
    safe_print("Reading Talabat's category list...")
    cat_names, all_keys, _ = read_category_tree()

    if FORCE_FULL:
        cat_keys = all_keys
        safe_print(f"Full mode: {len(cat_keys)} categories per branch.")
    else:
        allow = load_allowlist()
        cat_keys = [k for k in all_keys if k in allow]
        gone = sorted(allow - set(all_keys))
        if gone:
            safe_print(f"Note: {len(gone)} known categories no longer exist on "
                       f"Talabat and were skipped: {', '.join(gone)}")
        safe_print(f"Fast mode: {len(cat_keys)} Freshqa categories per branch "
                   f"(run --full now and then to catch new categories).")

    progress = load_progress(("full" if FORCE_FULL else "fast")
                             + ("-feed" + json.dumps(FEED_STATE["extra"], sort_keys=True)
                                if FEED_STATE["on"] else ""))
    try:
        state, incomplete = crawl(BRANCH_URLS, cat_keys, cat_names, progress)
    except KeyboardInterrupt:
        save_progress(progress)
        save_learned_speed()
        safe_print("\nStopped. Progress saved - run the same command to continue.")
        return 1

    if FORCE_FULL:
        found = {cat for (_l, cat), j in state.jobs.items()
                 if any(j["pages"].values())}
        save_allowlist(load_allowlist() | found)
        safe_print(f"\nCategory list refreshed: {len(found)} categories contain Freshqa.")

    complete = {b["label"]: branch_products(state, b["label"], cat_keys)
                for b in BRANCH_URLS if b["label"] not in incomplete}

    save_learned_speed()
    cells, added, fuzzy = write_results(TEMPLATE_PATH, complete, reset_columns=True,
                                        blank_labels=incomplete)
    elapsed = time.time() - start

    safe_print(f"\nSaved: {OUTPUT_PATH}")
    if FEED_STATE["broken"]:
        safe_print("Note: the product API stopped working - this run used web pages. "
                   "Run --probe-feed again to re-check it.")
    safe_print("=" * 60)
    safe_print(f"  TOTAL TIME TAKEN: {fmt_dur(elapsed)}   "
               f"(started {time.strftime('%H:%M:%S', time.localtime(start))}, "
               f"finished {time.strftime('%H:%M:%S')})")
    safe_print(f"  requests: {LIMITER.requests} | Talabat quota waits: {LIMITER.quota_waits} | "
               f"other push-backs: {LIMITER.blocks - LIMITER.quota_waits} | "
               f"timeouts/network retries: {_net['count']}")
    safe_print("=" * 60)
    for b in BRANCH_URLS:
        if b["label"] in complete:
            safe_print(f"  OK   {b['label']:<18} {len(complete[b['label']]):>4} Freshqa items")
    safe_print(f"{cells} cells written, {added} new product rows added.")
    print_fuzzy(fuzzy)

    if incomplete:
        safe_print(f"\n*** NOT COMPLETE: {', '.join(incomplete)} ***")
        safe_print("Those columns are left EMPTY in the output (not 0), so no fake "
                   "out-of-stock is shown. Run the SAME command again - only the "
                   "missing pages will be fetched.")
        return 2
    clear_progress()
    safe_print("\nAll branches complete.")
    return 0


def run_backfill(category_key):
    prepare()
    source = OUTPUT_PATH if os.path.exists(OUTPUT_PATH) else TEMPLATE_PATH
    safe_print(f"Backfill: '{category_key}' across {len(BRANCH_URLS)} branches -> {source}")
    try:
        cat_names, _, _ = read_category_tree()
    except FetchError:
        cat_names = {}
    progress = {"done": {}}  # backfill never touches the normal resume file
    state, incomplete = crawl(BRANCH_URLS, [category_key], cat_names, progress)
    results = {b["label"]: branch_products(state, b["label"], [category_key])
               for b in BRANCH_URLS if b["label"] not in incomplete}
    cells, added, fuzzy = write_results(source, results, reset_columns=False)
    safe_print(f"\nBackfill saved to {OUTPUT_PATH}: {cells} cells, {added} new rows.")
    print_fuzzy(fuzzy)
    if incomplete:
        safe_print(f"Not complete for: {', '.join(incomplete)} - run again to retry.")
        return 2
    return 0


def run_list(main_slug):
    _, _, cats = read_category_tree()
    for main in cats:
        if main.get("slug") == main_slug:
            print(f"{main.get('name')} ({main_slug}) - count={main.get('count')}")
            for sub in main.get("subCategories") or []:
                print(f"  - {sub.get('name')}  (slug: {main_slug}/{sub.get('slug')})  "
                      f"count={sub.get('count')}")
            return 0
    print(f"No top-level category '{main_slug}'. Available:")
    for main in cats:
        print(f"  - {main.get('slug')} ({main.get('name')})")
    return 0


def run_inspect():
    """Fetch ONE category page and report how Talabat structures it, to
    find out whether a brand filter exists (would cut requests ~10x)."""
    b = BRANCH_URLS[0]
    cat = "beverages/juices"
    url = page_url(b["_prefix"], b["_query"], cat, 1)
    print(f"Inspecting: {url}\n")
    data = fetch_next_data(url)
    with open("talabat_inspect.json", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    st = data.get("props", {}).get("pageProps", {}).get("initialState", {})
    print("initialState keys:", sorted(st.keys()))
    it = st.get("itemsData") or {}
    print("itemsData keys:   ", sorted(it.keys()) if isinstance(it, dict) else type(it))
    items = it.get("items") or []
    print(f"items on page 1: {len(items)}   pageCount: {it.get('pageCount')}")
    if items:
        print("item fields:     ", sorted(items[0].keys()))
    print("\nAnything that looks like a brand/filter/sort option:")
    hits = []

    def walk(o, path, depth):
        if depth > 7 or len(hits) > 60:
            return
        if isinstance(o, dict):
            for k, v in o.items():
                kl = str(k).lower()
                p = f"{path}.{k}"
                if any(w in kl for w in ("brand", "filter", "facet", "sort",
                                          "pagesize", "page_size", "limit", "query")):
                    preview = json.dumps(v, ensure_ascii=False)[:160]
                    hits.append(f"  {p} = {preview}")
                walk(v, p, depth + 1)
        elif isinstance(o, list) and o:
            walk(o[0], path + "[0]", depth + 1)

    walk(data, "data", 0)
    print("\n".join(hits) if hits else "  (nothing found)")
    print("\nFull page data saved to talabat_inspect.json")

    # Try a few ways of asking Talabat for ONLY Freshqa items / bigger pages.
    # One request each, no retries, spaced out - harmless if they don't exist.
    q = b["_query"]
    amp = "&" if q else "?"
    pre = b["_prefix"]
    candidates = [
        ("search ?q=",        f"{pre}/search{q}{amp}q=freshqa"),
        ("search ?query=",    f"{pre}/search{q}{amp}query=freshqa"),
        ("search ?term=",     f"{pre}/search{q}{amp}term=freshqa"),
        ("brand filter",      f"{pre}/{cat}{q}{amp}brands=freshqa"),
        ("bigger page size",  f"{pre}/{cat}{q}{amp}pageSize=100"),
    ]
    print("\nTesting shortcuts (one request each):")
    for label, u in candidates:
        time.sleep(3)
        try:
            r = http_get(u)
            m = NEXT_DATA_RE.search(r.text) if r.status_code == 200 else None
            if not m:
                print(f"  {label:<18} -> HTTP {r.status_code}, no product data")
                continue
            d = json.loads(m.group(1))
            idata = (d.get("props", {}).get("pageProps", {})
                     .get("initialState", {}).get("itemsData")) or {}
            its = idata.get("items") or [] if isinstance(idata, dict) else []
            fq = sum(1 for x in its if is_brand_match(x))
            print(f"  {label:<18} -> {len(its)} items, {fq} Freshqa, "
                  f"pageCount {idata.get('pageCount') if isinstance(idata, dict) else '?'}")
        except Exception as e:
            print(f"  {label:<18} -> error {e.__class__.__name__}")
    print("\nSend this whole output to Claude.")
    return 0


def run_probe_feed():
    """One-time test of Talabat's product API. ~15 single requests, 3s apart.
    Saves settings only if results are verified identical to normal pages."""
    b = BRANCH_URLS[0]
    cat = "beverages/juices"
    out = {"tested": datetime.datetime.now().isoformat()}

    def one(extra=None, page=1, cat_key=cat):
        time.sleep(3)
        url = feed_url(b, cat_key, page, extra)
        try:
            r = http_get(url)
        except requests.RequestException as e:
            return None, f"network error {e.__class__.__name__}"
        if r.status_code != 200:
            return None, f"HTTP {r.status_code}"
        d = _parse_json(r)
        if d is None:
            return None, "not JSON"
        return d, None

    def ids_of(items):
        return [str(x.get("id") or x.get("sku") or x.get("title")) for x in items]

    print(f"Probing Talabat product API on {b['label']} / {cat}\n")
    base, err = one()
    if err:
        print(f"Basic feed request failed: {err}. Nothing saved - web pages stay in use.")
        return 1
    with open("feed_probe.json", "w", encoding="utf-8") as f:
        json.dump(base, f, ensure_ascii=False, indent=1)
    items, pc = find_items_payload(base)
    print("Top-level keys:", sorted(base.keys()) if isinstance(base, dict) else type(base))
    if items is None:
        print("Could not find the item list in the response (saved to feed_probe.json).\n"
              "Send feed_probe.json to Claude. Nothing saved.")
        return 1
    print(f"Normal: {len(items)} items, pageCount {pc}, "
          f"{sum(map(is_brand_match, items))} Freshqa")
    if items:
        print("Item fields:", sorted(items[0].keys()))
    if pc is None:
        print("No page count in response - can't paginate safely. Nothing saved.")
        return 1
    base_n = len(items)

    print("\nTesting bigger pages:")
    size_hit = None
    for key in ("pageSize", "limit", "size", "perPage", "page_size", "pageLimit", "itemsPerPage"):
        d, err = one({key: 100})
        if err:
            print(f"  {key:<13} -> {err}")
            continue
        its, p2 = find_items_payload(d)
        n = len(its) if its is not None else 0
        print(f"  {key:<13} -> {n} items, pageCount {p2}")
        if its is not None and n > base_n and size_hit is None:
            size_hit = key

    print("\nTesting brand / search filters:")
    for key in ("brand", "brands", "brandSlug", "brandName", "q", "query", "search", "searchTerm"):
        d, err = one({key: "freshqa"})
        if err:
            print(f"  {key:<13} -> {err}")
            continue
        its, p2 = find_items_payload(d)
        if its is None:
            print(f"  {key:<13} -> unrecognised response")
            continue
        fq = sum(map(is_brand_match, its))
        flag = "   <-- FILTER WORKS?" if its and fq == len(its) else ""
        print(f"  {key:<13} -> {len(its)} items, {fq} Freshqa, pageCount {p2}{flag}")

    print("\nChecking the API returns exactly the same items as the web pages...")
    ok = True
    time.sleep(3)
    try:
        html = fetch_next_data(page_url(b["_prefix"], b["_query"], cat, 1))
        h_items, _ = find_items_payload(html)
        if h_items is None or sorted(ids_of(h_items)) != sorted(ids_of(items)):
            ok = False
            print("  page 1 differs from the web page - API NOT used.")
        else:
            print(f"  page 1 identical to web page ({len(items)} items).")
    except FetchError as e:
        ok = False
        print(f"  could not load web page to compare ({e}) - API NOT used.")

    extra = {}
    if ok and size_hit:
        # Verify big pages contain exactly all the items of the normal pages.
        small = []
        for pg in range(1, int(pc) + 1):
            d, err = one(page=pg)
            its, _ = find_items_payload(d) if d is not None else (None, None)
            if its is None:
                small = None
                break
            small += ids_of(its)
        big, bpc, pg = [], None, 1
        while small is not None:
            d, err = one({size_hit: 100}, page=pg)
            its, p2 = find_items_payload(d) if d is not None else (None, None)
            if its is None:
                big = None
                break
            big += ids_of(its)
            bpc = p2 or 1
            if pg >= bpc:
                break
            pg += 1
        if small and big is not None and sorted(set(small)) == sorted(set(big)):
            extra = {size_hit: 100}
            print(f"  bigger pages verified: {size_hit}=100 gives the same "
                  f"{len(set(small))} items in {bpc} request(s) instead of {pc}.")
        else:
            print("  bigger pages did NOT match exactly - using normal page size.")

    out.update({"works": ok, "extra": extra})
    with open(FEED_FILE, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print("\nSaved:", out)
    print("Normal runs will now use the product API." if ok else
          "Normal runs keep using web pages.")
    print("\nSend this whole output to Claude.")
    return 0


def main():
    for b in BRANCH_URLS:
        b["_prefix"], b["_query"] = get_base_parts(b["url"])
    try:
        if PROBE_FEED_MODE:
            return run_probe_feed()
        if INSPECT_MODE:
            return run_inspect()
        if LIST_CATEGORY:
            return run_list(LIST_CATEGORY)
        if BACKFILL_CATEGORY:
            return run_backfill(BACKFILL_CATEGORY)
        return run_normal()
    except FetchError as e:
        safe_print(f"\nCould not reach Talabat: {e}\nCheck your internet and try "
                   f"again in a few minutes.")
        return 3


if __name__ == "__main__":
    sys.exit(main())
